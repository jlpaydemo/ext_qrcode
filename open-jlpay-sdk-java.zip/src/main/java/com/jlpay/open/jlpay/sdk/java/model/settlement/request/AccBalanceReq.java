package com.jlpay.open.jlpay.sdk.java.model.settlement.request;

import com.jlpay.open.jlpay.sdk.java.model.OrgBaseReq;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * 结算资金查询请求参数
 *
 * @author zhaomeixia
 * @since 2024/1/25
 */
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AccBalanceReq extends OrgBaseReq {

    /**
     * 账户类型, 01: 清算户
     */
    private String acctType;

    @Override
    public String path() {
        return "/fund/settlement/account/balance";
    }
}
