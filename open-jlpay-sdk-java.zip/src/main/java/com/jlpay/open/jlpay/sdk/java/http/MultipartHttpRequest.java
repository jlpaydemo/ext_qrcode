package com.jlpay.open.jlpay.sdk.java.http;

import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/***
 * 表单请求参数
 * @author xuexiaoya
 * @date 2024/3/6
 **/
@Getter
@Setter
@ToString
public class MultipartHttpRequest {

    private HttpMethod method;

    private URL url;

    private Map<String, String> headers = new HashMap<>();

    private ObjectNode meta;
    private byte[] file;

    MultipartHttpRequest(final HttpMethod method, final URL url, final Map<String, String> headers, final ObjectNode meta, final byte[] file) {
        this.method = method;
        this.url = url;
        this.headers = headers;
        this.meta = meta;
        this.file = file;
    }

    public static Builder builder() {
        return new Builder();
    }

    private MultipartHttpRequest() {
    }

    public void addHeader(String name, String value) {
        headers.put(name, value);
    }

    public Builder toBuilder() {
        return new Builder().url(this.url).headers(new HashMap<>(this.headers)).meta(this.meta).file(this.file);
    }

    public static class Builder {
        private HttpMethod method;
        private URL url;
        private Map<String, String> headers;
        private ObjectNode meta;
        private byte[] file;

        Builder() {
        }

        public Builder method(final HttpMethod method) {
            this.method = method;
            return this;
        }

        public Builder url(final URL url) {
            this.url = url;
            return this;
        }

        public Builder headers(final Map<String, String> headers) {
            this.headers = headers;
            return this;
        }

        public Builder addHeader(String name, String value) {
            headers.put(name, value);
            return this;
        }


        public Builder meta(final ObjectNode meta) {
            this.meta = meta;
            return this;
        }

        public Builder file(final byte[] file) {
            this.file = file;
            return this;
        }

        public MultipartHttpRequest build() {
            return new MultipartHttpRequest(this.method, this.url, this.headers, this.meta, this.file);
        }


    }
}

