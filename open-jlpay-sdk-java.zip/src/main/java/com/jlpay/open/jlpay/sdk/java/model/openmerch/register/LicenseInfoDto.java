package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.LicenseType;
import lombok.*;

/**
 * 营业证明信息
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class LicenseInfoDto {
    /**
     * 执照类型
     */
    private LicenseType licenseType;

    /**
     * 注册号/统一社会信用代码
     */
    private String licenseNo;

    /**
     * 登记证书编号
     */
    private String certNumber;

    /**
     * 法定名称
     */
    private String licenseName;

    /**
     * 注册地址
     */
    private String licenseAddress;

    /**
     * 有效期开始日期
     */
    private String periodBegin;

    /**
     * 有效期结束日期
     */
    private String periodEnd;

    /**
     * 营业执照图片路径
     */
    private String licensePic;

    /**
     * 经营范围
     */
    private String businessScope;
}
