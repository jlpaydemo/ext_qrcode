package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 证件类型
 *
 * @author zhangyinda
 * @since 2024/3/16
 */
@Getter
@RequiredArgsConstructor
public enum IdType {
    /**
     * 身份证
     */
    ID_CARD("01"),

    /**
     * 护照
     */
    PASSPORT("02"),

    /**
     * 外地来往内地通行证
     */
    MAINLAND_TRAVEL_PERMIT("03"),

    /**
     * 港澳居民来往内地通行证
     */
    HK_MACAO_PASS("09"),

    /**
     * 台湾同胞来往内地通行证
     */
    TAIWAN_PASS("10"),

    /**
     * 外国人永久居留证
     */
    FOREIGNER_RESIDENCE_PERMIT("15"),

    /**
     * 其他
     */
    OTHER_ID("99");

    @JsonValue
    private final String code;
}
