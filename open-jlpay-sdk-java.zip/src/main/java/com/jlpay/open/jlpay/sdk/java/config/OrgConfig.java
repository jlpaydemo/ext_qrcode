package com.jlpay.open.jlpay.sdk.java.config;


import com.jlpay.open.jlpay.sdk.java.sign.SignVerifier;

import java.util.Objects;

/**
 * 机构配置
 *
 * @author zhaomeixia
 * @since 2024/2/20
 */
public class OrgConfig {

    /**
     * 嘉联分配的appId
     */
    private String appId;

    /**
     * 嘉联请求地址
     */
    private String url;

    /**
     * 机构私钥
     */
    private String orgPriKey;

    /**
     * 嘉联公钥
     */
    private String jlpayPubKey;

    /**
     * 是否强校验merchNo，默认为true
     */
    private Boolean verifyMerchNo;

    /**
     * 是否强校验orgNo，默认为true
     */
    private Boolean verifyOrgNo;

    /**
     * 敏感字段加密算法
     */
    private String cryptoAlg;

    /**
     * 敏感字段加密密钥(废弃)
     */
    private String cryptoKey;

    /**
     * 自动对敏感字段加密，默认为true
     */
    private Boolean autoEncrypt;

    /**
     * 自动对敏感字段解密，默认为true
     */
    private Boolean autoDecrypt;


    private OrgConfig(OrgConfigBuilder builder) {
        this.appId = builder.appId;
        this.url = builder.url;
        this.orgPriKey = builder.orgPriKey;
        this.jlpayPubKey = builder.jlpayPubKey;
        this.verifyMerchNo = builder.verifyMerchNo;
        this.verifyOrgNo = builder.verifyOrgNo;
        this.cryptoAlg = builder.cryptoAlg;
        this.cryptoKey = builder.cryptoKey;
        this.autoEncrypt = builder.autoEncrypt;
        this.autoDecrypt = builder.autoDecrypt;
    }

    public static OrgConfigBuilder builder() {
        return new OrgConfigBuilder();
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getOrgPriKey() {
        return orgPriKey;
    }

    public void setOrgPriKey(String privateKey) {
        this.orgPriKey = privateKey;
    }

    public String getJlpayPubKey() {
        return jlpayPubKey;
    }

    public void setJlpayPubKey(String jlpayPublicKey) {
        this.jlpayPubKey = jlpayPublicKey;
    }

    public Boolean getVerifyMerchNo() {
        return verifyMerchNo;
    }

    public void setVerifyMerchNo(Boolean verifyMerchNo) {
        this.verifyMerchNo = verifyMerchNo;
    }

    public Boolean getVerifyOrgNo() {
        return verifyOrgNo;
    }

    public void setVerifyOrgNo(Boolean verifyOrgNo) {
        this.verifyOrgNo = verifyOrgNo;
    }

    public String getCryptoAlg() {
        return cryptoAlg;
    }

    public void setCryptoAlg(String cryptoAlg) {
        this.cryptoAlg = cryptoAlg;
    }

    public String getCryptoKey() {
        return cryptoKey;
    }

    public void setCryptoKey(String cryptoKey) {
        this.cryptoKey = cryptoKey;
    }

    public Boolean getAutoEncrypt() {
        return autoEncrypt;
    }

    public void setAutoEncrypt(Boolean autoEncrypt) {
        this.autoEncrypt = autoEncrypt;
    }

    public Boolean getAutoDecrypt() {
        return autoDecrypt;
    }

    public void setAutoDecrypt(Boolean autoDecrypt) {
        this.autoDecrypt = autoDecrypt;
    }

    public SignVerifier createSignerVerifier() {
        return new SignVerifier(orgPriKey, jlpayPubKey);
    }

    public static class OrgConfigBuilder {
        private String appId;
        private String url;
        private String orgPriKey;
        private String jlpayPubKey;
        private Boolean verifyMerchNo = Boolean.TRUE;
        private Boolean verifyOrgNo = Boolean.TRUE;
        private String cryptoAlg;
        private String cryptoKey;
        private Boolean autoEncrypt = Boolean.FALSE;
        private Boolean autoDecrypt = Boolean.FALSE;

        public OrgConfigBuilder appId(String appId) {
            this.appId = appId;
            return this;
        }

        public OrgConfigBuilder url(String url) {
            this.url = url;
            return this;
        }

        public OrgConfigBuilder orgPriKey(String orgPriKey) {
            this.orgPriKey = Objects.requireNonNull(orgPriKey);
            return this;
        }

        public OrgConfigBuilder jlpayPubKey(String jlpayPubKey) {
            this.jlpayPubKey = Objects.requireNonNull(jlpayPubKey);
            return this;
        }

        public OrgConfigBuilder verifyMerchNo(Boolean verifyMerchNo) {
            this.verifyMerchNo = Objects.requireNonNull(verifyMerchNo);
            return this;
        }

        public OrgConfigBuilder verifyOrgNo(Boolean verifyOrgNo) {
            this.verifyOrgNo = Objects.requireNonNull(verifyOrgNo);
            return this;
        }

        public OrgConfigBuilder cryptoAlg(String cryptoAlg) {
            this.cryptoAlg = Objects.requireNonNull(cryptoAlg);
            return this;
        }

        public OrgConfigBuilder cryptoKey(String cryptoKey) {
            this.cryptoKey = Objects.requireNonNull(cryptoKey);
            return this;
        }

        public OrgConfigBuilder autoEncrypt(Boolean autoEncrypt) {
            this.autoEncrypt = Objects.requireNonNull(autoEncrypt);
            return this;
        }

        public OrgConfigBuilder autoDecrypt(Boolean autoDecrypt) {
            this.autoDecrypt = Objects.requireNonNull(autoDecrypt);
            return this;
        }

        public OrgConfig build() {
            Objects.requireNonNull(appId, "appId is required");
            Objects.requireNonNull(url, "url is required");
            return new OrgConfig(this);
        }
    }
}
