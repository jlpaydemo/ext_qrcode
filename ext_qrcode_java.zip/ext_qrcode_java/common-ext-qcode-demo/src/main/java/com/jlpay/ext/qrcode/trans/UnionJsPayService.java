package com.jlpay.ext.qrcode.trans;

import com.alibaba.fastjson.JSON;
import com.jlpay.ext.qrcode.contants.TransContants;
import com.jlpay.ext.qrcode.trans.request.UnionJsPayRequest;
import com.jlpay.ext.qrcode.trans.response.UnionJsPayResponse;
import com.jlpay.ext.qrcode.trans.service.TransExecuteService;
import org.apache.commons.lang3.RandomStringUtils;

/**
 * @Description: 閾惰仈琛屼笟鐮佹敮浠�
 * @author: lvlinyang
 * @date: 2019/11/25 10:53
 */
public class UnionJsPayService {

    static {
        //璁剧疆绯荤粺鍙傛暟
        TransContants.setJlpayProperty();
    }

    public static void main(String[] args) {

        //缁勮璇锋眰鍙傛暟
        UnionJsPayRequest request = componentRequestData();
        //浜ゆ槗璇锋眰
        UnionJsPayResponse response = TransExecuteService.executor("", request, UnionJsPayResponse.class);
        System.out.println("杩斿洖鍙傛暟=========>" + JSON.toJSON(response));

    }

    private static UnionJsPayRequest componentRequestData() {
        UnionJsPayRequest request = new UnionJsPayRequest();
        //蹇呬紶瀛楁
        request.setMchId("84931015812A00N");//鍢夎仈鍒嗛厤鐨勫晢鎴峰彿
        request.setOrgCode("50264239");//鍢夎仈鍒嗛厤鐨勬満鏋勫彿
        request.setNonceStr("123456789ABCDEFG");//闅忔満瀛楃涓�
        request.setPayType("unionpay");//浜ゆ槗绫诲瀷    wxpay銆乽nionpay
        request.setOutTradeNo("UNJS" + RandomStringUtils.randomNumeric(10));//鍟嗗绯荤粺鍐呴儴璁㈠崟鍙�   鏈烘瀯涓嬪敮涓�
        request.setTotalFee("1");//浜ゆ槗閲戦
        request.setBody("閾惰仈琛屼笟鐮佹敮浠樻祴璇�");//鍟嗗搧鍚�
        request.setTermNo("12345678");//缁堢鍙�   unionpay鏃跺繀椤�8浣�
        request.setDeviceInfo("800056");//缁堢璁惧鍙�
        request.setMchCreateIp("");//缁堢IP
        request.setNotifyUrl("http://172.20.6.23:50001/qrcode/trans/unionpay/notify/");//鍥炶皟鍦板潃
        request.setAttach("閾惰仈琛屼笟鐮佹敮浠樺晢鍝佹弿杩�");//鍟嗗搧鎻忚堪
        //闈炲繀浼犲瓧娈�
        request.setVersion("V1.0.1");//鐗堟湰鍙�
        request.setCharset("UTF-8");//瀛楃闆�
        request.setSignType("RSA256");//绛惧悕鏂瑰紡
        request.setRemark("閾惰仈琛屼笟鐮佹敮浠樺娉�");//澶囨敞
        request.setLongitude("");//缁忓害
        request.setLatitude("");//绾害
        request.setOpUserId("1001");//鎿嶄綔鍛�
        request.setOpShopId("100001");//闂ㄥ簵鍙�

        request.setUserId("XXXXXXXX");//閾惰仈浜岀淮鐮佺敤鎴锋爣璇�,閫氳繃鎺堟潈鐮佸拰APP鏍囪瘑鑾峰彇
        request.setPaymentValidTime("20");//璁㈠崟鏀粯鏈夋晥鏃堕棿,榛樿20鍒嗛挓

        return request;
    }

}
