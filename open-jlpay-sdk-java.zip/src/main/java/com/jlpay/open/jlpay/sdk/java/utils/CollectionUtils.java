package com.jlpay.open.jlpay.sdk.java.utils;

import java.util.Collection;

/**
 * @author chenjunhong
 * @date 2024/4/10
 */
public class CollectionUtils {
    public static boolean isNotEmpty(Collection<?> coll) {
        return !isEmpty(coll);
    }
    public static boolean isEmpty(Collection<?> coll) {
        return coll == null || coll.isEmpty();
    }
}
