package com.jlpay.open.jlpay.sdk.java.model.openmerch.change;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;

/**
 * 商户经营信息
 *
 * @author zhangyinda
 * @since 2024/4/8
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MerchBusinessInfoDto {
    /**
     * 商户号
     */
    private String merchNo;

    /**
     * 商户经营名称
     */
    private String merchShortname;

    /**
     * 银联经营名称
     */
    private String unionpayName;

    /**
     * 微信经营名称
     */
    private String wechatName;

    /**
     * 支付宝经营名称
     */
    private String alipayName;

    /**
     * 经营地址-省市区，省市区行政编码
     */
    private String addressCode;

    /**
     * 经营地址-详细地址，经营详细地址，精确到门牌号
     */
    private String addressDetail;

    /**
     * 所属行业，MCC行业编码
     */
    private String mccCode;

    /**
     * 客服电话，商户客服电话
     */
    private String csHotline;

    /**
     * 经营门头照，经营场所外景门头照片
     */
    private String doorPic;

    /**
     * 经营收银台，经营场所收银台照片
     */
    private String cashierPic;

    /**
     * 经营内景照，经营场所内部经营环境照片
     */
    private String indoorPic;
}

