package com.jlpay.open.jlpay.sdk.java.exception;

/**
 * 签名验证异常
 *
 * @author zhaomeixia
 * @since 2024/2/20
 */
public class SignVerifyException extends JlpayException {

    public SignVerifyException(String message) {
        super(message);
    }

    public SignVerifyException(String message, Throwable cause) {
        super(message, cause);
    }
}
