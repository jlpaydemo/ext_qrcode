package com.jlpay.ext.qrcode.trans.utils;

public enum HttpType {

    HTTP, HTTPS;
}
