package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 结算方式
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@RequiredArgsConstructor
public enum SettleMode {

    /**
     * 余额提现
     */
    BALANCE_WITHDRAWAL("0"),

    /**
     * 自动T1
     */
    AUTO_T1("1"),

    /**
     * T0
     */
    T0("2"),

    /**
     * 仅T1
     */
    ONLY_T1("3"),

    /**
     * 直连商户清算
     */
    DIRECT_MERCHANT_SETTLEMENT("5"),

    /**
     * 自动D1
     */
    AUTO_D1("6"),

    /**
     * 仅D1
     */
    ONLY_D1("7");

    private final String code;
}
