package com.jlpay.ext.qrcode.trans.utils;

public enum HttpRequestContextType {

    TEXT, XML, JSON, TEXT_WITH_FILE, BYTE_ARRAY
}
