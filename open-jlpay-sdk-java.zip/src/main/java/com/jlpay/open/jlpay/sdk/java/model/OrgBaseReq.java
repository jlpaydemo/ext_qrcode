package com.jlpay.open.jlpay.sdk.java.model;

import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * 机构基础请求参数
 *
 * @author zhaomeixia
 * @since 2024/1/26
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class OrgBaseReq {

    /**
     * 机构号
     */
    private String orgNo;

    /**
     * 商户号
     */
    private String merchNo;

    /**
     * SM2公钥加密后的敏感字段加密密钥
     */
    private String cryptoKey;

    public String path() {
        return "";
    }
}
