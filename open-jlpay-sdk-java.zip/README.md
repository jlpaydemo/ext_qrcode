### 功能

为第三方提供清结算、文件上传、开放平台等功能的OpenAPI SDK

### 使用方法

1. 在项目的pom.xml中引入OpenAPI的SDK
    ```xml
    <dependency>
        <groupId>com.jlpay</groupId>
        <artifactId>open-jlpay-sdk-java</artifactId>
        <version>1.0.0</version>
    </dependency>
    ```
2. 使用OpenAPI的SDK

   嘉联提供了OpenAPI的demo,目前除文件上传外的接口使用`JlpayOrgService`，文件上传接口使用`JlpayUploadFileService`
   具体接口的调用可以参考demo中的代码：https://gitlab.jlpay.com/pay-plus/open-api/clearing-demo

   此处给出一个简单的示例：
    ```java
    public class JlpayOpenApiService {
        /**
         * pem格式的机构私钥
         */
        private static final String ORG_PRIVATE_KEY = "***";
        /**
         * pem格式的嘉联公钥
         */
        private static final String JLPAY_PUBLIC_KEY = "***";
        
        private static final JlpayOrgService jlpayOrgService = createJlpayOrgService();
    
        private static final JlpayNotifyParseService jlpayNotifyParseService = createJlpayNotifyParseService();

        private JlpayOpenApiService() {
            throw new IllegalStateException("Utility class");
        }
    
        private static JlpayOrgService createJlpayOrgService() {
            OrgConfig orgConfig = OrgConfig.builder()
                    .appId("an132p3xk7pbugw")
                    .url("https://openapi-uat.jlpay.com")
                    .orgPriKey(ORG_PRIVATE_KEY)
                    .jlpayPubKey(JLPAY_PUBLIC_KEY)
                    .build();
            return new JlpayOrgService.Builder()
                    .config(orgConfig)
                    // 可以自定义HttpClient, 也可以不传, 默认使用DefaultHttpClientBuilder
                    .httpClient(new DefaultHttpClientBuilder()
                            .config(orgConfig)
                            .connectTimeoutMills(3000)
                            .readTimeoutMills(5000)
                            .writeTimeoutMills(5000)
                            .build())
                    .build();
        }
   
    private static JlpayNotifyParseService createJlpayNotifyParseService() {
        NotifyConfig config  = NotifyConfig.builder()
                .jlpayPubKey(JLPAY_PUBLIC_KEY)
                .build();
        return new JlpayNotifyParseService.Builder().config(config).build();
    }
    
        public static JlpayOrgService service() {
            return jlpayOrgService;
        }
   
       public static JlpayNotifyParseService notifyParseService() {
        return jlpayNotifyParseService;
    }

    }
    ```
   使用`JlpayOpenApiService`发送请求：

   1）清结算接口：
   ```java
       public static void main(String[] args) {
           WithdrawQueryReq withdrawQueryReq = WithdrawQueryReq.builder()
                   .outSettleId("1234567890125")
                   .merchNo("849584358120018")
                   .orgNo("123456")
                   .build();
           // 发送请求
           WithdrawQueryResp withdrawQueryResp = JlpayOpenApiService.service()
                   .post(withdrawQueryReq, WithdrawQueryResp.class);
           LOGGER.info("提现结果查询响应:{}", withdrawQueryResp);
       }
      ```
   2）文件上传接口：
      ```java
       public static void main(String[] args) throws IOException {
           VideoUploadReq req = new VideoUploadReq();
           req.setFileName("video.mp4");
           //支持 SM3和sha256
           req.setAlg(DigestAlgorithmType.SM3);
           String filePath = "D:\\video.mp4";
           req.setFile(Files.readAllBytes(Paths.get(filePath)));
           //发送请求
           FileUploadResponse response = JlpayOpenApiService.service()
                   .post(req, FileUploadResponse.class);
           LOGGER.info("视频上传结果查询响应:{}", response);
      }
      ```
   3）开放平台接口：
      ```java
      // 1. 入参不包含敏感字段
      public static void main(String[] args) {
        RealnameAliQueryRequest realnameAliQueryRequest = buildRealnameAliQueryRequest();
        RealnameAliQueryResponse realnameAliQueryResponse = JlpayOpenApiService.openMerchService()
                .post(realnameAliQueryRequest, RealnameAliQueryResponse.class);
        LOGGER.info("支付宝实名认证查询响应:{}", realnameAliQueryResponse);
      }
      // 2. 入参包含敏感字段
      public static void main(String[] args) {
        IncomingAddRequest incomingAddRequest = buildIncomingAddRequest();
        IncomingAddResponse incomingAddResponse = JlpayOpenApiService.openMerchWithCryptoService()
                .post(incomingAddRequest, IncomingAddResponse.class);
        LOGGER.info("商户进件响应:{}", incomingAddResponse);
      }
      // 3. 回调接口
      public static void main(String[] args) {
        // 替换为请求报文json
        String body = "{}";
        // 替换为回调接口uri
        String uri = "/notify";
        // 对应响应头x-jlpay-sign-alg
        String alg = SignType.SM3_WITH_SM2_WITH_DER.getCode();
        // 对应响应头x-jlpay-sign
        String sign = "MEYCIQCpHAZPdXEVbiGW17x9hY0JuEJ4eIX6Uo7Uxk9vczQk1wIhAPXsJHBVRQLiXTUFz15I8UHNLEcgWDwdDx5Uv8GN8Cuo";
        // 对应响应头x-jlpay-nonce
        String nonce = "QpPPCyWZFlgL1dI4MHJHVY37hqMN5YGG";
        // 对应响应头x-jlpay-timestamp
        String timestamp = "1711536850";
        NotifyParam notifyParam = NotifyParam.builder()
                .method(HttpMethod.POST.name())
                .uri(uri)
                .alg(alg)
                .sign(sign)
                .nonce(nonce)
                .timestamp(timestamp)
                .body(body)
                .build();
        ApplyResultRecord dto = null;
        try {
            dto = JlpayOpenApiService.openMerchNotifyParseService().parse(notifyParam, ApplyResultRecord.class);
        } catch (SignVerifyException e) {
            // 签名验证失败
            LOGGER.error("签名验证失败", e);
        }
        // 业务逻辑处理
      }
      ```
   此外，针对机构回调提供验签功能，
   ```java
    public static void main(String[] args) {
        // 请求体
        String msg = "{\"merch_no\":\"84944035812S123\"}";
        // 组装验签内容
        NotifyParam notifyParam = NotifyParam.builder()
                .method("POST")
                .uri("/verify")
                .alg(SignType.SM3_WITH_SM2_WITH_DER.getCode())
                .sign("sign")
                .nonce("DtIaE53ryRULHmmez7jbiyXE2YN7jgJJ")
                .timestamp("1710467996")
                .body(msg)
                .build();
        NotifyDto dto = null;
        try {
            dto = JlpayOpenApiService.notifyParseService().parse(notifyParam, NotifyDto.class);
        } catch (SignVerifyException e) {
            // 签名验证失败
            LOGGER.error("签名验证失败", e);
        }
    }
   ```
   1.0.2版本，新增对使用SM2WithSM4加密算法的请求报文进行敏感字段的自动加密和响应报文的敏感字段进行自动解密
   ```plain
   使用SM2WithSM4加密算法即orgConfig.cryptoAlg("SM2WithSM4")
   
   1. 默认不自动生成对称加密密钥和不自动对请求报文的敏感字段进行加密
   如果需要开启，设置orgConfig.autoEncrypt(Boolean.TRUE)
   如果不开启自动加密，可参考以下代码进行手动加密
   1) 并通过以下方法生成SM4对称加密密钥
   String key = KeyGenerateUtils.generateSm4Key(32 * 4);
   2) 然后请求类设置SM2算法加密后的SM4对称加密密钥
   String encryptedKey = CryptoHelper.encryptWithSm2(key, config.getJlpayPubKey());
   request.setCryptoKey(encryptedKey);
   3) 最后对请求报文的敏感字段进行加密
   request.setXxx(CryptoHelper.encryptWithSm4(xxx, key));
   
   2. 默认不自动对响应报文的敏感字段进行解密
   如果需要开启，设置orgConfig.autoDecrypt(Boolean.TRUE)
   如果不开启自动解密，可参考以下代码进行手动解密
   通过JlpayOrgService.post(request)方法获取HttpResponse
   然后从HttpResponse获取响应头x-jlpay-key和x-jlpay-crypto-alg
   1) SM2算法解密SM4对称加密密钥
   String key = CryptoHelper.decryptWithSm2(encryptedKey, config.getOrgPriKey());
   2) SM4算法解密敏感字段
   String plaintext = CryptoHelper.decryptWithSm4(cipherText, key);
   ```

### 其他

签名规则采用[开放接口统一签名方式](https://jlpay.yuque.com/fsx9z5/regckm/gk8uuowzqv938qcp)V5版本