package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;

/**
 * 字段审核不通过原因
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class FieldDetail {
    /**
     * 字段变量名
     */
    private String field;

    /**
     * 字段名称
     */
    private String fieldName;

    /**
     * 字段审核不通过原因
     */
    private String rejectReason;
}
