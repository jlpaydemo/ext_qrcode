package com.jlpay.open.jlpay.sdk.java.model.openmerch.alipay.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.BaseResponse;
import lombok.*;

/**
 * 支付宝实名认证查询响应
 *
 * @author chenjunhong
 * @since 2024/3/20
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class RealnameAliQueryResponse extends BaseResponse {

    /**
     * 申请状态，1-审核中，2-待确认联系信息，3-待账户验证，4-审核通过，5-审核驳回，6-已冻结，7-已作废（query_type=0时返回）
     */
    private String applymentStatus;

    /**
     * 二维码链接地址，二维码url地址（微信二维码有效期30分钟）
     */
    private String qrcodeData;

    /**
     * 驳回字段，驳回的字段名
     */
    private String rejectParam;

    /**
     * 审核驳回原因，实名认证驳回原因
     */
    private String rejectReason;

    /**
     * 授权状态，200-已授权，201-未授权（query_type=1时返回）
     */
    private String authorizeState;

}
