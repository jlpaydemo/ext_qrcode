package com.jlpay.open.jlpay.sdk.java.model.openmerch.change;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.BooleanEnum;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.SettleMode;
import lombok.*;

/**
 * 商户结算信息
 *
 * @author zhangyinda
 * @since 2024/4/8
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MerchSettleInfoDto {
    /**
     * 结算方式
     */
    private SettleMode settleMode;

    /**
     * 营业周期，结算日切时间
     */
    private String dayCut;

    /**
     * 结算场次
     */
    private String settleSession;

    /**
     * 是否允许商户自主变更结算账户
     */
    private BooleanEnum accountChangeFlag;

    /**
     * 结算附言
     */
    private String postscript;
}
