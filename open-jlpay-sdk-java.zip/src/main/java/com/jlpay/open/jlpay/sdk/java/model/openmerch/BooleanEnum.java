package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@RequiredArgsConstructor
public enum BooleanEnum {

    /**
     * FALSE
     */
    FALSE("0"),

    /**
     * TRUE
     */
    TRUE("1");

    @JsonValue
    private final String code;
}
