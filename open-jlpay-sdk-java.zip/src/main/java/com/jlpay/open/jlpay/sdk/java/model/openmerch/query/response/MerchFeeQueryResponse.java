package com.jlpay.open.jlpay.sdk.java.model.openmerch.query.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.BaseResponse;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.register.RateInfoDto;
import lombok.*;

import java.util.List;

/**
 * 商户主结算卡信息查询响应
 * @author chenjunhong
 * @date 2024/4/8
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MerchFeeQueryResponse extends BaseResponse {
    /**
     * 商户号
     */
    private String merchNo;

    /**
     * 费率列表
     */
    private List<RateInfoDto> rateInfo;
}
