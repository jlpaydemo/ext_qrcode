package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 文件类型
 *
 * @author zhangyinda
 * @since 2024/3/19
 */
@Getter
@RequiredArgsConstructor
public enum FileType {
    /**
     * 图片
     */
    IMAGE("1"),

    /**
     * PDF
     */
    PDF("2"),

    /**
     * 视频
     */
    VIDEO("3");

    @JsonValue
    private final String code;
}
