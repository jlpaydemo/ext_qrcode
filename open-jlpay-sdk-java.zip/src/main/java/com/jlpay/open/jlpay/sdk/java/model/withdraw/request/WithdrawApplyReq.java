package com.jlpay.open.jlpay.sdk.java.model.withdraw.request;

import com.jlpay.open.jlpay.sdk.java.model.OrgBaseReq;
import com.jlpay.open.jlpay.sdk.java.model.withdraw.SettleType;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * 结算交易请求参数
 *
 * @author zhaomeixia
 * @since 2024/1/22
 */
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class WithdrawApplyReq extends OrgBaseReq {

    /**
     * 结算类型
     */
    private SettleType settleType;

    /**
     * 结算单号
     */
    private String outSettleId;

    /**
     * 结算金额,单位为分
     */
    private String amount;

    /**
     * 银行账单附言
     */
    private String postscript;

    /**
     * 备注
     */
    private String remark;

    /**
     * 异步通知地址
     */
    private String notifyUrl;

    @Override
    public String path() {
        return "/fund/withdraw/apply";
    }
}
