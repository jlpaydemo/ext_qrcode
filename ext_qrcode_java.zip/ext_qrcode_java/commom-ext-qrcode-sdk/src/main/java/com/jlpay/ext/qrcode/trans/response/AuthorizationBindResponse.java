package com.jlpay.ext.qrcode.trans.response;

public class AuthorizationBindResponse extends TransBaseResponse {

}
