package com.jlpay.open.jlpay.sdk.java.exception;

/**
 * 嘉联异常抽象类
 *
 * @author zhaomeixia
 * @since 2024/2/20
 */
public abstract class JlpayException extends RuntimeException {

    JlpayException(String message) {
        super(message);
    }

    JlpayException(String message, Throwable cause) {
        super(message, cause);
    }
}
