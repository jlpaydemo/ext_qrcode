package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * @author zhangyinda
 * @since 2024/3/21
 */
@Getter
@RequiredArgsConstructor
public enum SettleRelation {
    /**
     * 股东
     */
    SHAREHOLDER_OR_EMPLOYEE("01", "股东"),

    /**
     * 总分公司
     */
    HEAD_AND_BRANCH_COMPANY("02", "总分公司"),

    /**
     * 母子公司
     */
    PARENT_SUBSIDIARY_COMPANY("03", "母子公司"),

    /**
     * 其他
     */
    OTHER("09", "其他");

    @JsonValue
    private final String code;
    private final String desc;
}
