package com.jlpay.ext.qrcode.trans.constants;

public class ExtConstants {

    public static final String orgPrivateKey = "qrcode.org.privatekey";
    public static final String jlpayPublicKey = "qrocde.jlpay.publickey";
    public static final String tradeUrl = "qrcode.jlpay.tradeUrl";
}
