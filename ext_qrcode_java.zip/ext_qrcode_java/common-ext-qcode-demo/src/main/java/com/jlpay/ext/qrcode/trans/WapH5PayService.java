package com.jlpay.ext.qrcode.trans;

import com.alibaba.fastjson.JSON;
import com.jlpay.ext.qrcode.contants.TransContants;
import com.jlpay.ext.qrcode.trans.request.WapH5PayRequest;
import com.jlpay.ext.qrcode.trans.response.WapH5PayResponse;
import com.jlpay.ext.qrcode.trans.service.TransExecuteService;
import org.apache.commons.lang3.RandomStringUtils;

/**
 * @author zhaoyang2
 * 鏀粯瀹濇湇鍔＄獥鏀粯demo
 */
public class WapH5PayService {

    static {
        //璁剧疆绯荤粺鍙傛暟
        TransContants.setJlpayProperty();
    }

    public static void main(String[] args) {
        //缁勮璇锋眰鍙傛暟
        WapH5PayRequest request = componentRequestData();
        //浜ゆ槗璇锋眰
        WapH5PayResponse response = TransExecuteService.executor("", request, WapH5PayResponse.class);
        System.out.println("杩斿洖鍙傛暟=========>" + JSON.toJSON(response));

    }

    private static WapH5PayRequest componentRequestData() {
        WapH5PayRequest request = new WapH5PayRequest();
        //蹇呬紶瀛楁
        request.setMchId("84931015812A00N");//鍢夎仈鍒嗛厤鐨勫晢鎴峰彿
        request.setOrgCode("50264239");//鍢夎仈鍒嗛厤鐨勬満鏋勫彿
        request.setNonceStr("123456789ABCDEFG");//闅忔満瀛楃涓�
        request.setPayType("alipay");//浜ゆ槗绫诲瀷    alipay:鏀粯瀹濇湇鍔＄獥,灏忕▼搴忔敮浠�
        request.setOutTradeNo("WAP" + RandomStringUtils.randomNumeric(10));//鍟嗗绯荤粺鍐呴儴璁㈠崟鍙�   鏈烘瀯涓嬪敮涓�
        request.setTotalFee("1");//浜ゆ槗閲戦
        request.setBody("鏀粯瀹濇湇鍔＄獥/灏忕▼搴忔敮浠�");//鍟嗗搧鍚�
        request.setTermNo("800056");//缁堢鍙�
        request.setDeviceInfo("800056");//缁堢璁惧鍙�
        request.setMchCreateIp("");//缁堢IP
        request.setNotifyUrl("http://172.20.6.23:50001/qrcode/trans/unionpay/notify/");//鍥炶皟鍦板潃
        request.setAttach("鏀粯瀹濇湇鍔＄獥鍟嗗搧鎻忚堪");//鍟嗗搧鎻忚堪
        //闈炲繀浼犲瓧娈�
        request.setBuyerLogonId("13720106549");//涔板鏀粯瀹濊处鍙�       buyer_logon_id鍜宐uyer_id涓嶈兘鍚屾椂涓虹┖
        request.setBuyerId("");//涔板鏀粯瀹濈敤鎴稩D    buyer_logon_id鍜宐uyer_id涓嶈兘鍚屾椂涓虹┖
        request.setVersion("V1.0.1");//鐗堟湰鍙�
        request.setCharset("UTF-8");//瀛楃闆�
        request.setSignType("RSA256");//绛惧悕鏂瑰紡
        request.setRemark("鏀粯瀹濇湇鍔＄獥澶囨敞");//澶囨敞
        request.setLongitude("");//缁忓害
        request.setLatitude("");//绾害
        request.setOpUserId("1001");//鎿嶄綔鍛�
        request.setOpShopId("100001");//闂ㄥ簵鍙�
        request.setPaymentValidTime("20");//璁㈠崟鏀粯鏈夋晥鏃堕棿,榛樿20鍒嗛挓

        return request;
    }

}
