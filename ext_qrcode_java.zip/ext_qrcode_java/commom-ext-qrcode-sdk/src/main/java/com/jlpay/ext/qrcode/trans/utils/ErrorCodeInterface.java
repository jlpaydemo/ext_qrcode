package com.jlpay.ext.qrcode.trans.utils;

public interface ErrorCodeInterface {

    public String getRetCode();

    public String getRetMsg();
}
