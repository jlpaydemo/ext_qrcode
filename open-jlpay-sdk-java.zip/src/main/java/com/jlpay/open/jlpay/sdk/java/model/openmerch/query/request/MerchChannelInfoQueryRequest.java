package com.jlpay.open.jlpay.sdk.java.model.openmerch.query.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.OrgBaseReq;
import lombok.*;

/**
 * 商户渠道信息查询请求
 * @author chenjunhong
 * @date 2024/4/9
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MerchChannelInfoQueryRequest extends OrgBaseReq {
    /**
     * 商户号
     */
    private String merchNo;

    @Override
    public String path() {
        return "/open/merch/access/merch-channel-info/query";
    }
}
