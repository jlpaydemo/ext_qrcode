package com.jlpay.open.jlpay.sdk.java.model.openmerch.register.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.BaseResponse;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.register.AuditDetail;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.List;

/**
 * @author liuaobo
 * createTime 2024/3/19
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class IncomingQueryResponse extends BaseResponse {
    /**
     * 业务申请编号
     */
    private String applyId;

    /**
     * 审核状态
     * 01：审核通过,
     * 02：审核中，
     * 09：审核驳回
     */
    private String auditStatus;

    /**
     * 审核驳回详情
     */
    private List<AuditDetail> auditDetail;

    /**
     * 审核驳回描述
     */
    private String auditFailure;

    /**
     * 商户号
     */
    private String merchNo;

    /**
     * 协议编号
     */
    private String signId;

    /**
     * 签约状态
     * 00:未签约
     * 01:已签约
     * 02:签约中
     * 09:签约失败
     */
    private String signStatus;

    /**
     * 协议链接
     */
    private String signUrl;

    /**
     * 委托合同协议编号
     */
    private String signDelegateeId;

    /**
     * 授权收款模式下，被授权人的签约状态
     */
    private String signDelegateeStatus;

    /**
     * 授权收款模式下，被授权人的承诺函、电子协议签约链接
     */
    private String signDelegateeUrl;

    /**
     * 终端号
     */
    private String termNo;

    /**
     * 审核时间
     * 该业务审核时间，时间格式“YYYY-MM-DD HH:MM:SS”
     * 商户核心没有该时间，开放平台记录获取到审核状态的时间为准。
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date auditEndTime;

    /**
     * 银联渠道报备结果
     * 01: 成功
     * 02: 处理中
     * 09: 失败
     */
    private String unionpayReportRet;

    /**
     * 银联报备结果描述
     */
    private String unionpayReportMsg;

    /**
     * 微信渠道报备结果
     * 01: 成功
     * 02: 处理中
     * 09: 失败
     */
    private String wechatReportRet;

    /**
     * 微信报备结果描述
     */
    private String wechatReportMsg;

    /**
     * 支付宝渠道报备结果
     * 01: 成功
     * 02: 处理中
     * 09: 失败
     */
    private String alipayReportRet;

    /**
     * 支付宝报备结果描述
     * 01: 成功
     * 02: 处理中
     * 09: 失败
     */
    private String alipayReportMsg;

    /**
     * appid绑定结果
     * 01: 成功
     * 02: 处理中
     * 09: 失败
     */
    private String subAppidBindRet;

    /**
     * 绑定结果描述
     */
    private String subAppidBindMsg;

    /**
     * 支付目录绑定结果
     * 01: 成功
     * 02: 处理中
     * 09: 失败
     */
    private String wechatJsapiPathRet;

    /**
     * 支付目录绑定结果描述
     * 01: 成功
     * 02: 处理中
     * 09: 失败
     */
    private String wechatJsapiPathMsg;

    /**
     * 入驻银行合作平台
     * 01: 成功
     * 02: 处理中
     * 09: 失败
     */
    private String coopBankRet;

    /**
     * 入驻结果描述
     */
    private String coopBankMsg;

}
