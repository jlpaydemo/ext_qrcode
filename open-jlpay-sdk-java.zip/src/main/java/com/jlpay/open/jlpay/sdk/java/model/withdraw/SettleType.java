package com.jlpay.open.jlpay.sdk.java.model.withdraw;

/**
 * 结算类型
 *
 * @author zhaomeixia
 * @since 2024/1/22
 */
public enum SettleType {

    /**
     * T0结算
     */
    T0,

    /**
     * T1结算
     */
    T1

}
