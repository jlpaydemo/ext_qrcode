package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 签约类型
 *
 * @author zhangyinda
 * @since 2024/3/16
 */
@Getter
@RequiredArgsConstructor
public enum SignMode {
    /**
     * 线下纸质协议
     */
    OFFLINE_PAPER_AGREEMENT("P"),
    /**
     * 线上电子协议
     */
    ONLINE_ELECTRONIC_AGREEMENT("E"),
    /**
     * 签约承若函
     */
    SIGNING_COMMITMENT_LETTER("L"),
    /**
     * 仅承诺函
     */
    SOLE_COMMITMENT_LETTER("C");

    @JsonValue
    private final String code;
}
