package com.jlpay.open.jlpay.sdk.java.utils.gm.keyentity;

import lombok.Getter;
import lombok.Setter;

/**
 * @author zhangyinda
 * @since 2024/2/20
 */
@Getter
@Setter
public class HsmKeyPair {
    private String privateKey;
    private String publicKey;
    private String key;

    public HsmKeyPair(String publicKey, String privateKey) {
        this.privateKey = privateKey;
        this.publicKey = publicKey;
    }

    public HsmKeyPair(String key) {
        this.key = key;
    }
}
