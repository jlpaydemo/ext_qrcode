package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Encrypt;
import lombok.*;

/**
 * 结算账户信息
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class AccountInfoDto {
    /**
     * 账号
     */
    @Encrypt
    private String accountNo;

    /**
     * 户名
     */
    @Encrypt
    private String accountName;

    /**
     * 开户银行
     */
    private String bankCode;

    /**
     * 开户支行编号
     */
    private String bankBranchId;

    /**
     * 开户行支行名称
     */
    private String bankBranchName;

    /**
     * 预留银行手机号码
     */
    @Encrypt
    private String bankSetPhone;

    /**
     * 被授权人姓名
     */
    @Encrypt
    private String delegateeName;

    /**
     * 被授权人身份证
     */
    @Encrypt
    private String delegateeIdCard;

    /**
     * 被授权人手机号
     */
    @Encrypt
    private String delegateePhone;

    /**
     * 收款人营业执照号码 企业非同名结算需要提供
     */
    private String delegateeLicenseNo;

    /**
     * 收款人营业执照名称 企业非同名结算需要提供
     */
    private String delegateeLicenseName;

    /**
     * 证件有效期开始时间,非法人结算、企业非同名结算需要提供
     */
    private String delegateeCertPeriodBegin;

    /**
     * 证件有效期结束时间,非法人结算、企业非同名结算需要提供
     */
    private String delegateeCertPeriodEnd;

    /**
     * 收款人证件类型
     */
    private String certType;

    /**
     * 结算账户照片
     */
    private String accountPic;
}
