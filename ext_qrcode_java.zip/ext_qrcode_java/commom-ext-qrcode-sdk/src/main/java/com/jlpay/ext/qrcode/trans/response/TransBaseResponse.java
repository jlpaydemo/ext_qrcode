package com.jlpay.ext.qrcode.trans.response;

import com.alibaba.fastjson.annotation.JSONField;

public class TransBaseResponse {

    @JSONField(name = "ret_code")
    private String retCode = "00";
    @JSONField(name = "ret_msg")
    private String retMsg = "处理成功";
    @JSONField(name = "sign")
    private String sign;

    public String getRetCode() {
        return retCode;
    }

    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    public String getRetMsg() {
        return retMsg;
    }

    public void setRetMsg(String retMsg) {
        this.retMsg = retMsg;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

}
