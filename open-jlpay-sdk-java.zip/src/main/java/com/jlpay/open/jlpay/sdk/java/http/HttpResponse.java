package com.jlpay.open.jlpay.sdk.java.http;

import lombok.*;

import java.util.Map;

/**
 * @author zhaomeixia
 * @since 2024/2/20
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class HttpResponse {

    @Singular("addHeader")
    private Map<String, String> headers;

    private String body;

    private int statusCode;
}
