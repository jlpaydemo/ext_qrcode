package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ChannelType {

    /**
     * 全渠道
     */
    ALL("00"),

    /**
     * 微信
     */
    WECHAT("01"),
    /**
     * 支付宝
     */
    ALIPAY("02");

    @JsonValue
    private final String code;

    public String getCode() {
        return code;
    }

}
