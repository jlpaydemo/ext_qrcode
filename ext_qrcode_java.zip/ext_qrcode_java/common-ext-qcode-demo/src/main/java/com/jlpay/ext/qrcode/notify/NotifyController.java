package com.jlpay.ext.qrcode.notify;

import com.alibaba.fastjson.JSON;
import com.jlpay.ext.qrcode.common.service.CommonService;
import com.jlpay.ext.qrcode.contants.TransContants;
import com.jlpay.ext.qrcode.trans.notify.JlpayNotifyVo;
import com.jlpay.ext.qrcode.trans.utils.ErrorConstants;
import com.jlpay.ext.qrcode.trans.utils.JlpayException;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author
 * @description
 * @date 2020/11/2
 */
@RestController
public class NotifyController {

    @RequestMapping(path = "/notify/")
    public String notify(@RequestBody String request) {
        String retCode = "success";
        try {
            if (StringUtils.isEmpty(request)) {
                throw new JlpayException(ErrorConstants.EMPTY, "参数异常");
            }
            System.out.println(String.format("接收到的回调参数:[%s]", request));
            CommonService.checkSign(request, TransContants.jlPubKey);
            JlpayNotifyVo jlpayNotifyVo = JSON.parseObject(request, JlpayNotifyVo.class);
            handBusi(jlpayNotifyVo);
        } catch (Exception e) {
            System.out.println("发生异常:");
            e.printStackTrace();
            retCode = "fail";
        }
        return retCode;
    }

    /**
     * 根据机构实际,进行业务处理
     *
     * @param jlpayNotifyVo
     */
    private void handBusi(JlpayNotifyVo jlpayNotifyVo) {
        /**
         * 目前嘉联后台通知机制是发起异步通知后，若未收到服务商系统正确响应，嘉联在24小时内会发起多次通知
         * 请务必做好放重措施
         */

    }
}
