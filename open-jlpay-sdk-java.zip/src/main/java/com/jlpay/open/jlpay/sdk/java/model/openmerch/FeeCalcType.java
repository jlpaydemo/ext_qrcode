package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * @author zhangyinda
 * @since 2024/3/22
 */
@Getter
@RequiredArgsConstructor
public enum FeeCalcType {

    /**
     * 内卡借记卡
     */
    DOMESTIC_DEBIT_CARD("01"),

    /**
     * 内卡贷记卡
     */
    DOMESTIC_CREDIT_CARD("02"),

    /**
     * 银联二维码
     */
    UNIONPAY_QRCODE("03"),

    /**
     * 外卡借记卡
     */
    INTERNATIONAL_DEBIT_CARD("11"),

    /**
     * 外卡贷记卡
     */
    INTERNATIONAL_CREDIT_CARD("12"),

    /**
     * 外币DCC
     */
    FOREIGN_CURRENCY_DCC("20"),

    /**
     * 外币EDC
     */
    FOREIGN_CURRENCY_EDC("21"),

    /**
     * 外币EDC虚拟卡
     */
    FOREIGN_CURRENCY_EDC_VM("22"),

    /**
     * QQ支付
     */
    QQ_PAY("29"),

    /**
     * 微信支付
     */
    WECHAT_PAY("30"),

    /**
     * 支付宝支付
     */
    ALIPAY("31"),

    /**
     * 快速提现
     */
    EXPRESS_WITHDRAWAL("T0");

    @JsonValue
    private final String code;

}
