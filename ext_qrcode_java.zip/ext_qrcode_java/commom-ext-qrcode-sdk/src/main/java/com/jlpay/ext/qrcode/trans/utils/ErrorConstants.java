package com.jlpay.ext.qrcode.trans.utils;

public class ErrorConstants {
    /***
     * 当数据为空时，用于JlpayAssert类中,断言Object为空，而实际上Object对象不为空时，抛出的异常代码
     */
    public static String EMPTY = "E0";
    /**
     * 验证错误代码，用于JlpayAssert类中，断言object不为空，而实际上为空时，抛出的异常代码。
     * 如果object对象为String对象时,如果String对象的值为"" 或者" "也认为是空对值，
     */
    public static String NOT_EMPTY = "E1";
    /**
     * 验证错误代码，用于JlpayAssert类中，断言表达式expression为true,而实际上却是false时，抛出的异常代码
     */
    public static String VALIDATE_ERROR_1 = "V1";
    /**
     * 验证错误代码，用于JlpayAssert类中，断言表达式expression为false,而实际上却是true时，抛出的异常代码
     */
    public static String VALIDATE_ERROR_2 = "V2";
    /**
     * 第三方业务系统时出现的系统超时代码
     */
    public static String NETWORK_TIME_OUT = "98";
    /**
     * 内部系统错误
     */
    public static String ERROR_CODE = "96";
    public static String MERCHANT_NOT_EXIST = "商户信息未注册";
    public static String ORDER_NOT_EXIST = "订单不存在";
    public static String ORDER_EXIST = "订单已存在";
}
