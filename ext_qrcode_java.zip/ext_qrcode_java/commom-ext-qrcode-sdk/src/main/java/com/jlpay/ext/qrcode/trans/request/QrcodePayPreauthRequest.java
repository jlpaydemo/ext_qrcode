package com.jlpay.ext.qrcode.trans.request;

import com.alibaba.fastjson.annotation.JSONField;

public class QrcodePayPreauthRequest extends TransBaseRequest {
    private String service = "qrcodepaypreauth";
    @JSONField(name = "pay_type")
    private String payType;
    @JSONField(name = "out_trade_no")
    private String outTradeNo;
    @JSONField(name = "body")
    private String body;
    @JSONField(name = "attach")
    private String attach;
    @JSONField(name = "total_fee")
    private String totalFee;
    @JSONField(name = "notify_url")
    private String notifyUrl;
    @JSONField(name = "mch_create_ip")
    private String mchCreateIp;

    @JSONField(name = "payment_valid_time")
    private String paymentValidTime;
    @JSONField(name = "profit_sharing")
    private String profitSharing;
    @JSONField(name = "remark")
    private String remark;
    @JSONField(name = "op_user_id")
    private String opUserId;
    @JSONField(name = "op_shop_id")
    private String opShopId;
    @JSONField(name = "trans_address")
    private String transAddress;
    @JSONField(name = "area_code")
    private String areaCode;
    @JSONField(name = "device_info")
    private String deviceInfo;
    @JSONField(name = "term_no")
    private String termNo;
    @JSONField(name = "longitude")
    private String longitude;
    @JSONField(name = "latitude")
    private String latitude;
    @JSONField(name = "sub_appid")
    private String subAppid;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getAttach() {
        return attach;
    }

    public void setAttach(String attach) {
        this.attach = attach;
    }

    public String getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(String totalFee) {
        this.totalFee = totalFee;
    }

    public String getNotifyUrl() {
        return notifyUrl;
    }

    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }

    public String getMchCreateIp() {
        return mchCreateIp;
    }

    public void setMchCreateIp(String mchCreateIp) {
        this.mchCreateIp = mchCreateIp;
    }

    public String getPaymentValidTime() {
        return paymentValidTime;
    }

    public void setPaymentValidTime(String paymentValidTime) {
        this.paymentValidTime = paymentValidTime;
    }

    public String getProfitSharing() {
        return profitSharing;
    }

    public void setProfitSharing(String profitSharing) {
        this.profitSharing = profitSharing;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getOpUserId() {
        return opUserId;
    }

    public void setOpUserId(String opUserId) {
        this.opUserId = opUserId;
    }

    public String getOpShopId() {
        return opShopId;
    }

    public void setOpShopId(String opShopId) {
        this.opShopId = opShopId;
    }

    public String getTransAddress() {
        return transAddress;
    }

    public void setTransAddress(String transAddress) {
        this.transAddress = transAddress;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(String deviceInfo) {
        this.deviceInfo = deviceInfo;
    }

    public String getTermNo() {
        return termNo;
    }

    public void setTermNo(String termNo) {
        this.termNo = termNo;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getSubAppid() {
        return subAppid;
    }

    public void setSubAppid(String subAppid) {
        this.subAppid = subAppid;
    }
}
