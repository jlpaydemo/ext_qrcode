package com.jlpay.open.jlpay.sdk.java.model.openmerch.change;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.ProductType;
import lombok.*;

/**
 * 商户基本信息
 *
 * @author zhangyinda
 * @since 2024/4/8
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MerchBaseInfoDto {
    /**
     * 业务申请编号
     */
    private String applyId;

    /**
     * 产品基本类型
     */
    private ProductType productType;
}
