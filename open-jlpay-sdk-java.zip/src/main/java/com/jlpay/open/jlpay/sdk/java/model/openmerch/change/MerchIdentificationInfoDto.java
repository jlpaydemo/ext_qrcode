package com.jlpay.open.jlpay.sdk.java.model.openmerch.change;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Encrypt;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.register.ProofInfoDto;
import lombok.*;

import java.util.List;

/**
 * 商户身份信息
 *
 * @author zhangyinda
 * @since 2024/4/8
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MerchIdentificationInfoDto {
    /**
     * 商户法定名称
     */
    private String licenseName;

    /**
     * 经营范围
     */
    private String businessScope;

    /**
     * 注册地址
     */
    private String licenseAddress;

    /**
     * 有效期限开始日期
     */
    private String periodBegin;

    /**
     * 有效期限结束日期
     */
    private String periodEnd;

    /**
     * 营业证明影像
     */
    private String licensePic;

    /**
     * 经营者/法人姓名
     */
    @Encrypt
    private String idCardName;

    /**
     * 经营者/法人英文名称
     */
    @Encrypt
    private String idCardEnglishName;

    /**
     * 经营者/法人身份证件号码
     */
    @Encrypt
    private String idCardNo;

    /**
     * 经营者/法人手机号码
     */
    @Encrypt
    private String legalPersonPhone;

    /**
     * 证件有效期-开始时间
     */
    private String cardPeriodBegin;

    /**
     * 证件有效期结束时间
     */
    private String cardPeriodEnd;

    /**
     * 证件正面
     */
    private String idCardCopy;

    /**
     * 证件反面
     */
    private String idCardNational;

    /**
     * 辅助证明材料
     */
    private List<ProofInfoDto> proofInfo;
}
