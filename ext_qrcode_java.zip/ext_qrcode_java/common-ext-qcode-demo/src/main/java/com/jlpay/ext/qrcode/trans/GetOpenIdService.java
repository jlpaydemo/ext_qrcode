package com.jlpay.ext.qrcode.trans;

import com.alibaba.fastjson.JSON;
import com.jlpay.ext.qrcode.contants.TransContants;
import com.jlpay.ext.qrcode.trans.request.GetOpenIdRequest;
import com.jlpay.ext.qrcode.trans.response.GetOpenIdResponse;
import com.jlpay.ext.qrcode.trans.service.TransExecuteService;

/**
 * @author zhaoyang2
 * 鎺堟潈鐮佽幏鍙杘penId鎴杣serId鐨刣emo
 * payType:wxpay 娴嬭瘯鐜鍙互楠岃瘉
 * payTYpe:unionpay 娴嬭瘯鐜鎶ユ枃浠呬緵鍙傝��
 */
public class GetOpenIdService {

    static {
        //璁剧疆绯荤粺鍙傛暟
        TransContants.setJlpayProperty();
    }

    public static void main(String[] args) {
        //缁勮璇锋眰鍙傛暟
        GetOpenIdRequest request = componentRequestData();
        //浜ゆ槗璇锋眰
        GetOpenIdResponse response = TransExecuteService.executor("getopenid", request, GetOpenIdResponse.class);
        System.out.println("杩斿洖鍙傛暟=========>" + JSON.toJSON(response));

    }

    private static GetOpenIdRequest componentRequestData() {
        GetOpenIdRequest request = new GetOpenIdRequest();
        //蹇呬紶瀛楁
        request.setMchId("84931015812A00N");//鍢夎仈鍒嗛厤鐨勫晢鎴峰彿
        request.setOrgCode("50264239");//鍢夎仈鍒嗛厤鐨勬満鏋勫彿
        request.setNonceStr("123456789");//闅忔満瀛楃涓�
        request.setPayType("wxpay");//浜ゆ槗绫诲瀷    wxpay銆乽nionpay
        request.setAuthCode("134519057319081876");//鎺堟潈鐮�  unionpay:Y/uPmzGRTDuU3eNSzpepYg== 浠呬緵鍙傝��
        //闈炲繀浼犲瓧娈�
        request.setSubAppid("");//鍏紬璐﹀彿ID
//		request.setAppUpIdentifier("UnionPay/1.0 CloudPay");//閾惰仈鏀粯鏍囪瘑  閾惰仈浜岀淮鐮佸繀閫�
        request.setVersion("V1.0.1");//鐗堟湰鍙�
        request.setCharset("UTF-8");//瀛楃闆�
        request.setSignType("RSA256");//绛惧悕鏂瑰紡

        return request;
    }

}
