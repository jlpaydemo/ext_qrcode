package com.jlpay.open.jlpay.sdk.java.model.openmerch.register.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.DataCrypto;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Encrypt;
import com.jlpay.open.jlpay.sdk.java.model.OrgBaseReq;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.register.*;
import lombok.*;

/**
 * 商户进件信息
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@DataCrypto(encrypt = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class IncomingAddRequest extends OrgBaseReq {

    /**
     * 基础信息
     */
    @Encrypt
    private BaseInfoDto baseInfo;

    /**
     * 身份信息
     */
    @Encrypt
    private IdentificationInfoDto identificationInfo;

    /**
     * 经营信息
     */
    private BusinessInfoDto businessInfo;

    /**
     * 结算信息
     */
    @Encrypt
    private SettlementInfoDto settlementInfo;

    /**
     * 结算规则
     */
    private SettlementRuleDto settlementRule;

    /**
     * 补充信息
     */
    @Encrypt
    private AdditionalInfoDto additionalInfo;

    @Override
    public String path() {
        return "/open/merch/access/incoming/add";
    }
}
