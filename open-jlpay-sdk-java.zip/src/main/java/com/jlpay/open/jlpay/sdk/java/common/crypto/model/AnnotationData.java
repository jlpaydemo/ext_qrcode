package com.jlpay.open.jlpay.sdk.java.common.crypto.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.lang.reflect.Field;

/**
 * @Description 注解标识的数据，用于反射改值 field.set(obj,newValue)
 * @Author guo wei
 * @Date 2022/6/19 20:51
 */
@AllArgsConstructor
@Data
public class AnnotationData {
    /**
     * 对象
     */
    private Object obj;
    /**
     * 属性
     */
    private Field field;
    /**
     * 原属性值
     */
    private Object oldValue;
}
