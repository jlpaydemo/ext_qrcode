package com.jlpay.open.jlpay.sdk.java.model.upload.response;

import com.jlpay.open.jlpay.sdk.java.model.BaseResponse;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * 文件上传响应
 *
 * @author xuexiaoya
 * @version 2024/02/21
 **/
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class FileUploadResponse extends BaseResponse {

    /**
     * 媒体文件标识
     */
    private String mediaId;
}
