package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;

/**
 * 其他资料
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class OtherInfoDto {
    /**
     * 结算账户公司营业执照
     */
    private String acctLicense;

    /**
     * 法人人脸图片
     */
    private String identityFacePic;

    /**
     * 法人鉴权凭证号
     */
    private String identityAuthId;

    /**
     * 结算账户人的身份证件正面
     */
    private String acctCertFrontPic;

    /**
     * 结算账户人的身份证件反面
     */
    private String acctCertBackPic;

    /**
     * 结算账户人人脸照片
     */
    private String acctFacePic;
}
