package com.jlpay.open.jlpay.sdk.java.model.openmerch.alipay.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.OrgBaseReq;
import lombok.*;

/**
 * 支付宝实名认证查询请求
 *
 * @author chenjunhong
 * @since 2024/3/20
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class RealnameAliQueryRequest extends OrgBaseReq {

    /**
     * 商户号
     */
    private String merchNo;

    /**
     * 查询类型，0-申请单查询（默认），1-授权结果查询
     */
    private String queryType = "0";

    @Override
    public String path() {
        return "/open/merch/access/alipay/realname/query";
    }

}
