package com.jlpay.ext.qrcode.trans.response;

import com.alibaba.fastjson.annotation.JSONField;

public class OrderQueryResponse extends TransBaseResponse {

    @JSONField(name = "status")
    private String status;
    @JSONField(name = "mch_id")
    private String mchId;
    @JSONField(name = "org_code")
    private String orgCode;
    @JSONField(name = "transaction_id")
    private String transactionId;
    @JSONField(name = "out_trade_no")
    private String outTradeNo;
    @JSONField(name = "total_fee")
    private String totalFee;
    @JSONField(name = "order_time")
    private String orderTime;
    @JSONField(name = "term_no")
    private String termNo;
    @JSONField(name = "device_info")
    private String deviceInfo;
    @JSONField(name = "op_user_id")
    private String opUserId;
    @JSONField(name = "op_shop_id")
    private String opShopId;
    @JSONField(name = "finnal_amount")
    private String finnalAmount;
    @JSONField(name = "discount_amount")
    private String discountAmount;
    @JSONField(name = "discount_name")
    public String discountName;
    @JSONField(name = "coupon_Info")
    private String couponInfo;
    @JSONField(name = "remark")
    private String remark;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMchId() {
        return mchId;
    }

    public void setMchId(String mchId) {
        this.mchId = mchId;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(String totalFee) {
        this.totalFee = totalFee;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public String getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(String deviceInfo) {
        this.deviceInfo = deviceInfo;
    }

    public String getOpUserId() {
        return opUserId;
    }

    public void setOpUserId(String opUserId) {
        this.opUserId = opUserId;
    }

    public String getOpShopId() {
        return opShopId;
    }

    public void setOpShopId(String opShopId) {
        this.opShopId = opShopId;
    }

    public String getFinnalAmount() {
        return finnalAmount;
    }

    public void setFinnalAmount(String finnalAmount) {
        this.finnalAmount = finnalAmount;
    }

    public String getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(String discountAmount) {
        this.discountAmount = discountAmount;
    }

    public String getDiscountName() {
        return discountName;
    }

    public void setDiscountName(String discountName) {
        this.discountName = discountName;
    }

    public String getCouponInfo() {
        return couponInfo;
    }

    public void setCouponInfo(String couponInfo) {
        this.couponInfo = couponInfo;
    }

    public String getTermNo() {
        return termNo;
    }

    public void setTermNo(String termNo) {
        this.termNo = termNo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

}
