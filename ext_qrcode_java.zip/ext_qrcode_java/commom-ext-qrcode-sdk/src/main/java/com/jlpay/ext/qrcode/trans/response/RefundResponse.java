package com.jlpay.ext.qrcode.trans.response;

import com.alibaba.fastjson.annotation.JSONField;

public class RefundResponse extends TransBaseResponse {

    @JSONField(name = "status")
    private String status;
    @JSONField(name = "mch_id")
    private String mchId;
    @JSONField(name = "transaction_id")
    private String transactionId;
    @JSONField(name = "out_trade_no")
    private String outTradeNo;
    @JSONField(name = "ori_out_trade_no")
    private String oriOutTradeNo;
    @JSONField(name = "total_fee")
    private String totalFee;
    @JSONField(name = "order_time")
    private String orderTime;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMchId() {
        return mchId;
    }

    public void setMchId(String mchId) {
        this.mchId = mchId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getOriOutTradeNo() {
        return oriOutTradeNo;
    }

    public void setOriOutTradeNo(String oriOutTradeNo) {
        this.oriOutTradeNo = oriOutTradeNo;
    }

    public String getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(String totalFee) {
        this.totalFee = totalFee;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

}
