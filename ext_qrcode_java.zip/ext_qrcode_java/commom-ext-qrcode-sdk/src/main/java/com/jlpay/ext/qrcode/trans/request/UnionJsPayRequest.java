package com.jlpay.ext.qrcode.trans.request;

import com.alibaba.fastjson.annotation.JSONField;

public class UnionJsPayRequest extends TransBaseRequest {

    private String service = "unionjspay";
    @JSONField(name = "pay_type")
    private String payType;
    @JSONField(name = "out_trade_no")
    private String outTradeNo;
    @JSONField(name = "total_fee")
    private String totalFee;
    @JSONField(name = "body")
    private String body;
    @JSONField(name = "term_no")
    private String termNo;
    @JSONField(name = "device_info")
    private String deviceInfo;
    @JSONField(name = "mch_create_ip")
    private String mchCreateIp;
    @JSONField(name = "notify_url")
    private String notifyUrl;
    @JSONField(name = "attach")
    private String attach;
    @JSONField(name = "user_auth_code")
    private String userAuthCode;
    @JSONField(name = "app_up_identifier")
    private String appUpIdentifier;

    @JSONField(name = "user_id")
    private String userId;

    @JSONField(name = "profit_sharing")
    private String profitSharing;

    @JSONField(name = "remark")
    private String remark;
    @JSONField(name = "longitude")
    private String longitude;
    @JSONField(name = "latitude")
    private String latitude;
    @JSONField(name = "op_user_id")
    private String opUserId;
    @JSONField(name = "op_shop_id")
    private String opShopId;
    @JSONField(name = "payment_valid_time")
    private String paymentValidTime;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(String totalFee) {
        this.totalFee = totalFee;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(String deviceInfo) {
        this.deviceInfo = deviceInfo;
    }

    public String getMchCreateIp() {
        return mchCreateIp;
    }

    public void setMchCreateIp(String mchCreateIp) {
        this.mchCreateIp = mchCreateIp;
    }

    public String getNotifyUrl() {
        return notifyUrl;
    }

    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }

    public String getAttach() {
        return attach;
    }

    public void setAttach(String attach) {
        this.attach = attach;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getOpUserId() {
        return opUserId;
    }

    public void setOpUserId(String opUserId) {
        this.opUserId = opUserId;
    }

    public String getOpShopId() {
        return opShopId;
    }

    public void setOpShopId(String opShopId) {
        this.opShopId = opShopId;
    }

    public String getTermNo() {
        return termNo;
    }

    public void setTermNo(String termNo) {
        this.termNo = termNo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getUserAuthCode() {
        return userAuthCode;
    }

    public void setUserAuthCode(String userAuthCode) {
        this.userAuthCode = userAuthCode;
    }

    public String getAppUpIdentifier() {
        return appUpIdentifier;
    }

    public void setAppUpIdentifier(String appUpIdentifier) {
        this.appUpIdentifier = appUpIdentifier;
    }

    public String getProfitSharing() {
        return profitSharing;
    }

    public void setProfitSharing(String profitSharing) {
        this.profitSharing = profitSharing;
    }

    public String getPaymentValidTime() {
        return paymentValidTime;
    }

    public void setPaymentValidTime(String paymentValidTime) {
        this.paymentValidTime = paymentValidTime;
    }
}
