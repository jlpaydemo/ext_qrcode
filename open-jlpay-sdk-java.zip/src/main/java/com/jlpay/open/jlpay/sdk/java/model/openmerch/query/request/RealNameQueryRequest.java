package com.jlpay.open.jlpay.sdk.java.model.openmerch.query.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.OrgBaseReq;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.ChannelType;
import lombok.*;

/**
 * @author liuaobo
 * createTime 2024/3/23
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class RealNameQueryRequest extends OrgBaseReq {
    /**
     * 商户号
     */
    private String merchNo;

    /**
     * 0-申请单查询（默认），1-授权结果查询
     */
    private String queryType;

    /**
     * 00：所有渠道   默认00
     * 01:   wechat
     * 02：alipay
     */
    private ChannelType channelType = ChannelType.ALL;

    @Override
    public String path() {
        return "/open/merch/access/realname/query";
    }
}
