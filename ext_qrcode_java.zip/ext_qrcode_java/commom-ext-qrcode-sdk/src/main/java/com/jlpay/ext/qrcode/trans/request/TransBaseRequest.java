package com.jlpay.ext.qrcode.trans.request;

import com.alibaba.fastjson.annotation.JSONField;

public class TransBaseRequest {

    @JSONField(name = "mch_id")
    private String mchId;
    @JSONField(name = "org_code")
    private String orgCode;
    @JSONField(name = "nonce_str")
    private String nonceStr;

    @JSONField(name = "version")
    private String version;
    @JSONField(name = "charset")
    private String charset;
    @JSONField(name = "sign_type")
    private String signType;
    private String service;

    public String getMchId() {
        return mchId;
    }

    public void setMchId(String mchId) {
        this.mchId = mchId;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getNonceStr() {
        return nonceStr;
    }

    public void setNonceStr(String nonceStr) {
        this.nonceStr = nonceStr;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public String getSignType() {
        return signType;
    }

    public void setSignType(String signType) {
        this.signType = signType;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }
}
