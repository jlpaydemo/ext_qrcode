package com.jlpay.ext.qrcode.trans.request;

import com.alibaba.fastjson.annotation.JSONField;

public class OrderChnQueryRequest extends TransBaseRequest {

    private String service = "chnquery";
    @JSONField(name = "out_trade_no")
    private String outTradeNo;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

}
