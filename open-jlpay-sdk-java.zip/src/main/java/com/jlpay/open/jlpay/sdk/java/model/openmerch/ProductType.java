package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 产品类型
 *
 * @author zhangyinda
 * @since 2024/3/16
 */
@Getter
@RequiredArgsConstructor
public enum ProductType {
    /**
     * 扫码商户:只能码付交易
     */
    QR_CODE_MERCHANT("01","02"),

    /**
     * 标准商户:银行卡+码付交易
     */
    STANDARD_MERCHANT("02","01"),

    /**
     * 场景商户:特定经营场景商户
     */
    SCENARIO_MERCHANT("03","03");

    @JsonValue
    private final String code;
    private final String desc;
}
