package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.BooleanEnum;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.SettleMode;
import lombok.*;

/**
 * 结算设置
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class SettleInfoDto {
    /**
     * 结算方式
     */
    private SettleMode settleMode;

    /**
     * 营业周期
     */
    private String dayCut;

    /**
     * 是否允许变更结算账户
     */
    private BooleanEnum accountChangeFlag;

    /**
     * 结算附言
     */
    private String postscript;
}
