package com.jlpay.open.jlpay.sdk.java.http;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zhaomeixia
 * @since 2024/2/19
 */
@Getter
@Setter
@ToString
public class HttpRequest {

    private HttpMethod method;

    private URL url;

    private Map<String, String> headers = new HashMap<>();

    private String body;

    public static Builder builder() {
        return new Builder();
    }

    public void addHeader(String name, String value) {
        headers.put(name, value);
    }

    public Builder toBuilder() {
        return new Builder().url(this.url).headers(new HashMap<>(this.headers)).body(this.body);
    }

    public static class Builder {
        private HttpMethod method;
        private URL url;
        private Map<String, String> headers = new HashMap<>();
        private String body;

        private Builder() {
        }

        public Builder method(HttpMethod method) {
            this.method = method;
            return this;
        }

        public Builder url(URL url) {
            this.url = url;
            return this;
        }

        public Builder headers(Map<String, String> headers) {
            this.headers = headers;
            return this;
        }

        public Builder addHeader(String name, String value) {
            headers.put(name, value);
            return this;
        }

        public Builder body(String body) {
            this.body = body;
            return this;
        }

        public HttpRequest build() {
            HttpRequest httpRequest = new HttpRequest();
            httpRequest.setMethod(method);
            httpRequest.setUrl(url);
            httpRequest.setHeaders(headers);
            httpRequest.setBody(body);
            return httpRequest;
        }
    }
}
