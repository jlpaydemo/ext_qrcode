package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;

import java.util.List;

/**
 * 审核驳回详情
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class AuditDetail {

    /**
     * 模块变量名
     */
    private String module;

    /**
     * 模块中文名
     */
    private String moduleName;

    /**
     * 模块审核不通过原因
     */
    private String failedReason;

    /**
     * 字段审核不通过原因
     */
    private List<FieldDetail> moduleDetail;

}
