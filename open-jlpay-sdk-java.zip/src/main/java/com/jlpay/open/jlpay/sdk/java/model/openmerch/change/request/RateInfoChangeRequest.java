package com.jlpay.open.jlpay.sdk.java.model.openmerch.change.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.OrgBaseReq;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.register.RateInfoDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * 商户费率修改请求
 *
 * @author zhangyinda
 * @since 2024/4/8
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class RateInfoChangeRequest extends OrgBaseReq {
    /**
     * 业务申请编号
     */
    private String applyId;

    /**
     * 商户号
     */
    private String merchNo;

    /**
     * 费率列表
     */
    private List<RateInfoDto> rateInfo;

    @Override
    public String path() {
        return "/open/merch/access/rate-info/modify";
    }
}
