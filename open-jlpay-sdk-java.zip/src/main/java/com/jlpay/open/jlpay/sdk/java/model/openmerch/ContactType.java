package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 联系人类型
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@RequiredArgsConstructor
public enum ContactType {

    /**
     * 经营者/法人
     */
    OWNER_OR_LEGAL_PERSON("65"),

    /**
     * 经办人
     */
    OPERATOR("66");

    @JsonValue
    private final String code;
}
