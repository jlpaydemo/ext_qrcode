package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Encrypt;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.Gender;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.IdType;
import lombok.*;

/**
 * 经营者/法人信息
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class IdentityInfoDto {

    /**
     * 证件类型
     */
    private IdType idDocType;

    /**
     * 经营者/法人姓名
     */
    @Encrypt
    private String idCardName;

    /**
     * 经营者/法人的证件英文名称
     */
    @Encrypt
    private String idCardEnglishName;

    /**
     * 经营者/法人证件号码
     */
    @Encrypt
    private String idCardNo;

    /**
     * 经营者/法人手机号码
     */
    @Encrypt
    private String legalPersonPhone;

    /**
     * 证件有效期-开始时间
     */
    private String cardPeriodBegin;

    /**
     * 证件有效期-结束时间
     */
    private String cardPeriodEnd;

    /**
     * 证件登记地址
     */
    @Encrypt
    private String idCardAddress;

    /**
     * 证件正面照片
     */
    private String idCardCopy;

    /**
     * 证件反面照片
     */
    private String idCardNational;

    /**
     * 性别
     */
    private Gender gender;

    /**
     * 国籍
     */
    private String nationality;
}
