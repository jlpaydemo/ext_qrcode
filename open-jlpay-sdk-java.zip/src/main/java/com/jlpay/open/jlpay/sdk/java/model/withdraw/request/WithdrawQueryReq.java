package com.jlpay.open.jlpay.sdk.java.model.withdraw.request;

import com.jlpay.open.jlpay.sdk.java.model.OrgBaseReq;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * 结算查询请求参数
 *
 * @author zhaomeixia
 * @since 2024/1/23
 */
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class WithdrawQueryReq extends OrgBaseReq {

    /**
     * 外部结算编号
     */
    private String outSettleId;

    /**
     * 结算订单号
     */
    private String settleId;

    @Override
    public String path() {
        return "/fund/withdraw/query";
    }
}
