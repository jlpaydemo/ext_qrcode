package com.jlpay.ext.qrcode.trans.utils;

/**
 * 线上错误码枚举
 *
 * @author shuqingzhou
 */
public enum ExceptionCode {

    SUCCESS("00", "成功"),
    SYSTEM_ERROR("ZZ", "系统异常"),
    /**
     * 签名验签
     **/
    SIGN_VERIFY_ERROR("V1", "签名验证失败"),
    SIGN_MD5_KEY_ERROR("V2", "未设置MD5 KEY"),
    SIGN_RSA_KEY_ERROR("V3", "未设置RSA证书"),
    SIGN_RSA_SIGN_ERROR("V4", "RSA签名失败"),
    /**
     * 签名验签
     **/

    VERIFYCODE_ERROR("W0", "验证码错误"),
    SESSION_EXPIRED("W1", "session已失效，请重新登录"),
    NOT_ALLOWED_OP("W2", "权限不足"),
    DUPLICATE_INSERT("WD", "新增数据重复"),
    ASSERT_ERROR("WX", "数据错误"),
    VALID_ERROR("WV", "数据格式错误"),
    NO_RECORD("WN", "没有符合条件的记录"),
    HTTP_ERROR("WH", "通讯异常"),;
    private String code;
    private String msg;

    private ExceptionCode(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    /**
     * 获取指定对象
     *
     * @param val
     * @return
     */
    public static ExceptionCode find(String val) {
        if (val == null) {
            return null;
        }
        for (ExceptionCode record : values()) {
            if (val.equals(record.getCode())) {
                return record;
            }
        }
        return null;
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
