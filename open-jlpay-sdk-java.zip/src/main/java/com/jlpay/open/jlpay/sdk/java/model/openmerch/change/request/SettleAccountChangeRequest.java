package com.jlpay.open.jlpay.sdk.java.model.openmerch.change.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.DataCrypto;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Encrypt;
import com.jlpay.open.jlpay.sdk.java.model.OrgBaseReq;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.SettleType;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.register.ProofInfoDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * 商户账户信息修改请求
 *
 * @author liuaobo
 * @since 2024/3/27
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@DataCrypto(encrypt = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class SettleAccountChangeRequest extends OrgBaseReq {
    /**
     * 业务申请编号
     */
    private String applyId;

    /**
     * 商户号
     */
    private String merchNo;

    /**
     * 结算类型
     */
    private SettleType settleType;

    /**
     * 结算账户名
     */
    @Encrypt
    private String accountName;

    /**
     * 账号
     */
    @Encrypt
    private String accountNo;

    /**
     * 开户银行
     */
    private String bankCode;

    /**
     * 开户支行编号
     */
    private String bankBranchId;

    /**
     * 开户支行名称
     */
    private String bankBranchName;

    /**
     * 结算账户照片
     */
    private String accountPic;

    /**
     * 预留银行手机号码
     */
    @Encrypt
    private String bankSetPhone;

    /**
     * 收款人证件类型
     */
    private String certType;

    /**
     * 收款人证件号码
     */
    @Encrypt
    private String delegateeIdCard;

    /**
     * 收款人证件有效期开始日期，yyyy-MM-dd
     */
    private String delegateeCertPeriodBegin;

    /**
     * 收款人证件有效期结束日期，yyyy-MM-dd
     */
    private String delegateeCertPeriodEnd;

    /**
     * 结算账户公司营业执照照片
     */
    private String acctLicense;

    /**
     * 结算账户人的身份证件正面
     */
    private String acctCertFrontPic;

    /**
     * 结算账户人的身份证件反面
     */
    private String acctCertBackPic;

    /**
     * 结算账户收款确认书
     */
    private String acctAuthLetter;

    /**
     * 法人人脸图片
     */
    private String identityFacePic;

    /**
     * 结算账户人脸图片
     */
    private String acctFacePic;

    /**
     * 辅助证明材料
     */
    private List<ProofInfoDto> proofInfo;

    @Override
    public String path() {
        return "/open/merch/access/settle-info/modify";
    }
}
