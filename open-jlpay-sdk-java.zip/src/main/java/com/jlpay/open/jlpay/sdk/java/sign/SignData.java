package com.jlpay.open.jlpay.sdk.java.sign;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zhangyinda
 * @since 2024/1/26
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class SignData {
    private static final String SEPARATOR = "\n";
    private String method;
    private String uri;
    private String timestamp;
    private String nonce;
    private String body;

    public String buildSignContent() {
        return method + SEPARATOR
                + uri + SEPARATOR
                + timestamp + SEPARATOR
                + nonce + SEPARATOR
                + body + SEPARATOR;
    }
}
