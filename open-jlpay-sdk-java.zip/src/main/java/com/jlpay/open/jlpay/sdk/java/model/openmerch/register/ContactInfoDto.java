package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Encrypt;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.ContactType;
import lombok.*;

/**
 * 联系人信息
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ContactInfoDto {

    /**
     * 联系人类型
     */
    private ContactType contactType;

    /**
     * 联系人姓名
     */
    @Encrypt
    private String contactName;

    /**
     * 联系人手机号码
     */
    @Encrypt
    private String contactPhone;

    /**
     * 联系人证件号码
     */
    @Encrypt
    private String contactIdNo;

    /**
     * 联系人证件有效期开始时间
     */
    private String contactPeriodBegin;

    /**
     * 联系人证件有效期结束时间
     */
    private String contactPeriodEnd;

    /**
     * 联系人证件正面照片
     */
    private String contactIdDocCopy;

    /**
     * 联系人证件反面照片
     */
    private String contactIdDocNational;
}
