package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 结算类型
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@RequiredArgsConstructor
public enum SettleType {
    /**
     * 打款至法人银行卡 -> 法人结算
     */
    TO_OWNER_BANK_CARD("01"),

    /**
     * 打款至对公账户 -> 企业结算
     */
    TO_CORPORATE_ACCOUNT("02"),

    /**
     * 打款至他人银行卡 -> 非法人结算
     */
    TO_OTHER_BANK_CARD("03"),

    /**
     * 打款至他人对公账户 -> 企业非同名结算
     */
    TO_OTHER_CORPORATE_ACCOUNT("04");

    @JsonValue
    private final String code;
}
