package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.FeeCalcType;
import lombok.*;

/**
 * @author zhangyinda
 * @since 2024/3/22
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class RateInfoDto {
    /**
     * 计费类型
     */
    private FeeCalcType feeCalcType;

    /**
     * 起始金额区间，默认0
     */
    private String minAmt;

    /**
     * 截止金额区间(含)(-1无穷大)，默认-1
     */
    private String maxAmt;

    /**
     * 费率标识 0:固定费率，1:固定金额，默认0
     */
    private String fixed;

    /**
     * 费率
     */
    private String rate;

    /**
     * 最低收费，默认0
     */
    private String bottom;

    /**
     * 封顶收费(-1不封顶)，默认-1
     */
    private String top;

    /**
     * 阶梯收费(分为单位)，默认0
     */
    private String step;

    /**
     * 阶梯基础金额(分为单位)，默认0
     */
    private String baseAmount;

    /**
     * 阶梯基础金额以下收费(分为单位)，默认0
     */
    private String baseFee;
}
