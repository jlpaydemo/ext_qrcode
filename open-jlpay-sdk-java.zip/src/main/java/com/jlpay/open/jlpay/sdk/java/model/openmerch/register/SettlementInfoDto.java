package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;


import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Encrypt;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.SettleRelation;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.SettleType;
import lombok.*;

/**
 * 结算信息
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class SettlementInfoDto {

    /**
     * 结算类型
     */
    private SettleType settleType;

    /**
     * 结算关系
     */
    private SettleRelation settleRelation;

    /**
     * 结算关系详情
     */
    private String settleRelationDetail;

    /**
     * 账户信息
     */
    @Encrypt
    private AccountInfoDto accountInfo;

    /**
     * 其他信息
     */
    private OtherInfoDto otherInfo;
}
