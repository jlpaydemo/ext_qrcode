package com.jlpay.open.jlpay.sdk.java.exception;

/**
 * HTTP 请求执行异常
 *
 * @author zhaomeixia
 * @since 2024/2/20
 */
public class HttpExecutionException extends JlpayException {

    public HttpExecutionException(String message) {
        super(message);
    }

    public HttpExecutionException(String message, Throwable cause) {
        super(message, cause);
    }
}
