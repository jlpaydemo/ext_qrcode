package com.jlpay.open.jlpay.sdk.java.model.openmerch.query.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.DataCrypto;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Decrypt;
import com.jlpay.open.jlpay.sdk.java.model.BaseResponse;
import lombok.*;

/**
 * 商户主结算卡信息查询响应
 * @author chenjunhong
 * @date 2024/4/8
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@DataCrypto(decrypt = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MerchMasterSettCardQueryResponse extends BaseResponse {
    /**
     * 商户号
     */
    private String merchNo;

    /**
     * 商户名称
     */
    private String merchName;

    /**
     * 结算类型
     */
    private String settleType;

    /**
     * 户名
     */
    @Decrypt
    private String accountName;

    /**
     * 账号
     */
    @Decrypt
    private String accountNo;

    /**
     * 开户银行编码
     */
    private String bankCode;

    /**
     * 开户支行编号
     */
    private String bankBranchId;

    /**
     * 开户支行名称
     */
    private String bankBranchName;
}
