package com.jlpay.open.jlpay.sdk.java.enums;

/**
 * @author chenjunhong
 * @date 2024/4/12
 */
public enum BaseResponseCode {
    /**
     * 成功
     */
    SUCCESS("00", "Success"), /**
     * 成功 v5
     */
    SUCCESS_V5("00000", "Success"), /**
     * 系统异常
     */
    FAIL("99", "System Error");
    private final String retCode;
    private final String retMsg;

    public String getRetCode() {
        return this.retCode;
    }

    public String getRetMsg() {
        return this.retMsg;
    }

    private BaseResponseCode(final String retCode, final String retMsg) {
        this.retCode = retCode;
        this.retMsg = retMsg;
    }
}
