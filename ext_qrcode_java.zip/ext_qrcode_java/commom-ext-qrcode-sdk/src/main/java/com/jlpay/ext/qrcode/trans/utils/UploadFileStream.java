package com.jlpay.ext.qrcode.trans.utils;

import java.io.InputStream;

public class UploadFileStream {

    private InputStream stream;
    private String fileName;

    @SuppressWarnings("unused")
    private UploadFileStream() {
    }

    public UploadFileStream(InputStream stream, String fileName) {
        this.stream = stream;
        this.fileName = fileName;

    }

    public InputStream getStream() {
        return stream;
    }

    public void setStream(InputStream stream) {
        this.stream = stream;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

}
