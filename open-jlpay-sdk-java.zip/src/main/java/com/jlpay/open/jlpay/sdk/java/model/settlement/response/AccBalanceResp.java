package com.jlpay.open.jlpay.sdk.java.model.settlement.response;

import com.jlpay.open.jlpay.sdk.java.model.BaseResponse;
import com.jlpay.open.jlpay.sdk.java.model.settlement.AccountStatus;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * 结算资金查询响应
 *
 * @author zhaomeixia
 * @since 2024/1/25
 */
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AccBalanceResp extends BaseResponse {

    /**
     * 账户余额
     */
    private String balance;

    /**
     * 可用余额
     */
    private String availableBalance;

    /**
     * 冻结金额
     */
    private String frozenAmount;

    /**
     * 账户状态
     */
    private AccountStatus status;
}
