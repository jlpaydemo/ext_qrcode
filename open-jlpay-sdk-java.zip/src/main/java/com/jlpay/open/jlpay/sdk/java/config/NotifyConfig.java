package com.jlpay.open.jlpay.sdk.java.config;


import com.jlpay.open.jlpay.sdk.java.sign.SignVerifier;

import java.util.Objects;


/***
 * 回调配置
 * @author xuexiaoya
 * @date 2024/3/15
 **/
public class NotifyConfig {

    /**
     * 嘉联公钥
     */
    private String jlpayPubKey;

    private NotifyConfig(Builder builder) {
        this.jlpayPubKey = builder.jlpayPubKey;
    }

    public static Builder builder() {
        return new Builder();
    }


    public String getJlpayPubKey() {
        return jlpayPubKey;
    }

    public void setJlpayPubKey(String jlpayPublicKey) {
        this.jlpayPubKey = jlpayPublicKey;
    }

    public SignVerifier createSignerVerifier() {
        return new SignVerifier(jlpayPubKey);
    }

    public static class Builder {

        private String jlpayPubKey;


        public Builder jlpayPubKey(String jlpayPubKey) {
            this.jlpayPubKey = Objects.requireNonNull(jlpayPubKey);
            return this;
        }

        public NotifyConfig build() {
            return new NotifyConfig(this);
        }
    }
}
