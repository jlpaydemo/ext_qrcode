package com.jlpay.ext.qrcode.trans.response;

import com.alibaba.fastjson.annotation.JSONField;

public class GetOpenIdResponse extends TransBaseResponse {

    @JSONField(name = "open_id")
    private String openId;
    @JSONField(name = "sub_open_id")
    private String subOpenId;
    @JSONField(name = "user_id")
    private String userId;

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getSubOpenId() {
        return subOpenId;
    }

    public void setSubOpenId(String subOpenId) {
        this.subOpenId = subOpenId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

}
