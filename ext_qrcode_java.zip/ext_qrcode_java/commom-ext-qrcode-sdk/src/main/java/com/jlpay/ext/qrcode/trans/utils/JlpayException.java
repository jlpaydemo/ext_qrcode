package com.jlpay.ext.qrcode.trans.utils;

/**
 * 自定义异常类
 *
 * @author lujianyuan
 */
public class JlpayException extends IllegalArgumentException {

    private static final long serialVersionUID = 1L;
    private String code;

    public JlpayException(String code, String msg) {
        super(msg);
        this.code = code;
    }

    public JlpayException(ErrorCodeInterface errorcode) {
        super(errorcode.getRetMsg());
        this.code = errorcode.getRetCode();
    }

    public JlpayException(String code, String msg, Throwable e) {
        super(msg, e);
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public JlpayException(ExceptionCode ec) {
        super(ec.getMsg());
        this.code = ec.getCode();
    }

    public JlpayException(ExceptionCode ec, Throwable e) {
        super(ec.getMsg(), e);
        this.code = ec.getCode();
    }

    public JlpayException(ExceptionCode ec, String message) {
        super(message);
        this.code = ec.getCode();
    }

    public JlpayException(ExceptionCode ec, String message, Throwable e) {
        super(message, e);
        this.code = ec.getCode();
    }
}
