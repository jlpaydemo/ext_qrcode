package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Encrypt;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.MerchType;
import lombok.*;

/**
 * 身份信息
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class IdentificationInfoDto {

    /**
     * 主体类型
     */
    private MerchType merchType;

    /**
     * 营业证明信息
     */
    private LicenseInfoDto licenseInfo;

    /**
     * 经营者/法人信息
     */
    @Encrypt
    private IdentityInfoDto identityInfo;
}
