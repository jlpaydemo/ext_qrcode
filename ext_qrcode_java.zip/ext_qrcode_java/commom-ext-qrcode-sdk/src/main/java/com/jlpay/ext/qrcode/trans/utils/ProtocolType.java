package com.jlpay.ext.qrcode.trans.utils;

public enum ProtocolType {
    SSLv2Hello("SSLv2Hello"), SSLv3("SSLv3"), TLSv1("TLSv1"), TLSv1_2("TLSv1.2"), TLSv1_1("TLSv1.1");
    private String desc;

    private ProtocolType(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

}
