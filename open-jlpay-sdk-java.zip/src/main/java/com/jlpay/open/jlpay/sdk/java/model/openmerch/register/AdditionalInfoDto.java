package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Encrypt;
import lombok.*;

import java.util.List;

/**
 * 补充信息
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class AdditionalInfoDto {
    /**
     * 报备相关
     */
    private ReportInfoDto reportInfo;

    /**
     * 辅助证明材料
     */
    private List<ProofInfoDto> proofInfo;

    /**
     * 辅助证明材料
     */
    private CoopBankInfoDto coopBankInfo;

    /**
     * 合规相关
     */
    @Encrypt
    private SpecsInfoDto specsInfo;
}
