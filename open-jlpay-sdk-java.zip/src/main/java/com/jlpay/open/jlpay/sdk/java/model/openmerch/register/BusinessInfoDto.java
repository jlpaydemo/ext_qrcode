package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;

/**
 * 经营信息
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class BusinessInfoDto {

    /**
     * 商户经营名称
     */
    private String merchShortname;

    /**
     * 商户英文名称
     */
    private String merchEnglishName;

    /**
     * 所属行业MCC码
     */
    private String mccCode;

    /**
     * 业务场景编号
     */
    private String sceneId;

    /**
     * 经营地址-省市区地区编码
     */
    private String addressCode;

    /**
     * 经营地址-详细地址
     */
    private String addressDetail;

    /**
     * 经营场所门头照
     */
    private String doorPic;

    /**
     * 经营场所内景照
     */
    private String indoorPic;

    /**
     * 经营场所收银台照片
     */
    private String cashierPic;

    /**
     * 客服电话
     */
    private String csHotLine;
}
