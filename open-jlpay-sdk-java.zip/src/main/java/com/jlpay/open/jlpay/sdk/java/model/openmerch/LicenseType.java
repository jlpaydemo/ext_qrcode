package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 执照类型
 *
 * @author zhangyinda
 * @since 2024/3/16
 */
@Getter
@RequiredArgsConstructor
public enum LicenseType {
    /**
     * 个体户
     */
    SOLE_PROPRIETORSHIP("01","PER"),

    /**
     * 企业
     */
    COMPANY("02","COM"),

    /**
     * 政府机关
     */
    GOVERNMENT_AGENCY("03","GOV"),

    /**
     * 事业单位
     */
    PUBLIC_INSTITUTION("04","INS"),

    /**
     * 其他组织
     */
    OTHER_ORGANIZATION("05","ORG");

    @JsonValue
    private final String code;
    private final String value;
}
