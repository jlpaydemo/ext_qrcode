package com.jlpay.open.jlpay.sdk.java.model.withdraw.response;

import com.jlpay.open.jlpay.sdk.java.model.BaseResponse;
import com.jlpay.open.jlpay.sdk.java.model.withdraw.SettleType;
import com.jlpay.open.jlpay.sdk.java.model.withdraw.WithdrawApplyStatus;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.Date;

/**
 * 结算查询响应
 *
 * @author zhaomeixia
 * @since 2024/1/23
 */
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class WithdrawQueryResp extends BaseResponse {

    /**
     * 结算类型
     */
    private SettleType settleType;

    /**
     * 结算付款金额,单位为分
     */
    private String amount;

    /**
     * 付款状态
     */
    private WithdrawApplyStatus resultState;

    /**
     * 结算付款时间
     */
    private Date paymentTime;

    /**
     * 嘉联系统订单号
     */
    private String settleId;

    /**
     * 外部结算编号
     */
    private String outSettleId;

    /**
     * 手续费
     */
    private String feeAmount;

    /**
     * 附言
     */
    private String postscript;
}
