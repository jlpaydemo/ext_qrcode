package com.jlpay.open.jlpay.sdk.java.model.openmerch.query.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.BaseResponse;
import lombok.*;

import java.util.List;

/**
 * 商户渠道信息查询响应
 * @author chenjunhong
 * @date 2024/4/9
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MerchChannelInfoQueryResponse extends BaseResponse {
    /**
     * 商户号
     */
    private String merchNo;

    /**
     * 商户名称
     */
    private String merchName;

    /**
     * 渠道信息
     */
    private List<ChannelInfo> channelInfo;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
    public static class ChannelInfo {
        /**
         * 渠道ID
         * 15-银联
         * 26-连通
         * 10011-银联微信
         * 10009-银联支付宝
         * 10017-网联微信
         * 10018-网联支付宝
         */
        private String channelId;

        /**
         * 报备状态
         * 0-报备中
         * 1-报备成功
         * 2-报备失败
         */
        @JsonProperty("report_status")
        private String reportedFlag;

        /**
         * 渠道商户号
         */
        private String channelMerchNo;

        /**
         * 失败原因
         */
        private String failReason;

        /**
         * 渠道商户名称
         */
        private String channelMerchName;

        /**
         * 渠道商户经营名称
         */
        @JsonProperty("channel_merch_shortname")
        private String channelBusinessName;

        /**
         * 报备时间
         */
        @JsonProperty("report_time")
        private String reportedTime;

        /**
         * 渠道服务商编号
         */
        private String channelOrgId;

        /**
         * 费率类型
         */
        @JsonProperty("fee_type")
        private String rateType;
    }
}
