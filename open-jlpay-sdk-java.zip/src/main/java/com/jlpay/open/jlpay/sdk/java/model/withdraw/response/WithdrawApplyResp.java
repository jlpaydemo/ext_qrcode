package com.jlpay.open.jlpay.sdk.java.model.withdraw.response;

import com.jlpay.open.jlpay.sdk.java.model.BaseResponse;
import com.jlpay.open.jlpay.sdk.java.model.withdraw.SettleType;
import com.jlpay.open.jlpay.sdk.java.model.withdraw.WithdrawApplyStatus;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * 结算交易响应参数
 *
 * @author zhaomeixia
 * @since 2024/1/22
 */
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class WithdrawApplyResp extends BaseResponse {

    /**
     * 结算付款金额
     */
    private String amount;

    /**
     * 结算类型
     */
    private SettleType settleType;

    /**
     * 付款状态
     */
    private WithdrawApplyStatus resultState;

    /**
     * 返回信息
     */
    private String resultMsg;

    /**
     * 系统订单号
     */
    private String settleId;

    /**
     * 外部结算编号
     */
    private String outSettleId;

    /**
     * 手续费
     */
    private String feeAmount;
}
