package com.jlpay.open.jlpay.sdk.java.model.upload.request;


import com.jlpay.open.jlpay.sdk.java.enums.DigestAlgorithmType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/***
 * 上传基础请求参数
 * @author xuexiaoya
 * @date 2024/3/6
 **/
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UploadBaseReq {

    /**
     * 文件名
     */
    private String fileName;

    /**
     * 摘要算法类型
     */
    private DigestAlgorithmType alg;

    /**
     * 文件二进制内容
     */
    private byte[] file;

    public String path() {
        return "";
    }
}
