package com.jlpay.ext.qrcode.trans.utils;

public interface IHttpService {

    public HttpResult execute(HttpRequestModel requestModel);

    public HttpResult execute(HttpRequestModel requestModel, String p12Path, String password);
}
