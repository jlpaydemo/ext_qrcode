package com.jlpay.open.jlpay.sdk.java.utils;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author xuexiaoya
 * @version 2024/03/06
 **/
public class HttpUtils {

    public static URL parseUrl(String urlString) {
        try {
            return new URL(urlString);
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException("Invalid uri syntax", e);
        }
    }
}
