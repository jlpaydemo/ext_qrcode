package com.jlpay.open.jlpay.sdk.java.enums;

import java.util.Arrays;

/***
 * 签名类型
 * @author xuexiaoya
 * @date 2024/3/14
 **/
public enum SignType {

    /**
     * SM3WithSM2WithDer
     */
    SM3_WITH_SM2_WITH_DER("SM3WithSM2WithDer");

    /**
     * code
     */
    private final String code;

    SignType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static SignType getByCode(String code) {
        return Arrays.stream(values())
                .filter(enumValue -> enumValue.code.equals(code))
                .findFirst()
                .orElse(null);
    }
}
