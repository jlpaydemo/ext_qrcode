package com.jlpay.open.jlpay.sdk.java.model.settlement;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @author zhaomeixia
 * @since 2024/1/25
 */
public enum AccountStatus {

    /**
     * 正常
     */
    NORMAL("N", "正常"),

    /**
     * 停用
     */
    DISABLED("C", "停用"),

    /**
     * 冻结
     */
    FROZEN("F", "冻结"),

    /**
     * 销户
     */
    CLOSED("D", "销户");

    @JsonValue
    private final String code;

    private final String desc;

    AccountStatus(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
