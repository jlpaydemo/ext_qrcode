package com.jlpay.ext.qrcode.trans.request;

import com.alibaba.fastjson.annotation.JSONField;

public class PreauthQueryRequest extends TransBaseRequest {
    private String service = "preauthquery";
    @JSONField(name = "out_trade_no")
    private String outTradeNo;

    @JSONField(name = "transaction_id")
    private String transactionId;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }


}
