package com.jlpay.open.jlpay.sdk.java.model.openmerch.query.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.DataCrypto;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Decrypt;
import com.jlpay.open.jlpay.sdk.java.model.BaseResponse;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.register.RateInfoDto;
import lombok.*;

import java.util.List;

/**
 * 商户基本信息查询响应
 * @author chenjunhong
 * @date 2024/3/29
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@DataCrypto(decrypt = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MerchBaseInfoQueryResponse extends BaseResponse {
    // 基础信息
    /**
     * 商户号
     */
    private String merchNo;

    /**
     * 商户名称
     */
    private String merchName;

    /**
     * 商户状态
     */
    private String merchStatus;

    /**
     * 产品类型
     */
    private String productType;

    /**
     * 协议类型
     */
    private String signMode;

    /**
     * 服务商编号
     */
    private String agentId;

    // 进件结果
    /**
     * 协议编号
     */
    private String signId;

    /**
     * 协议链接
     */
    private String signUrl;

    // 经营信息
    /**
     * 商户经营名称
     */
    private String merchShortname;

    /**
     * 商户英文名称
     */
    private String merchEnglishName;

    /**
     * 经营地址-省市区
     */
    private String addressCode;

    /**
     * 经营地址-详细地址
     */
    private String addressDetail;

    /**
     * 所属行业
     */
    private String mccCode;

    // 结算设置
    /**
     * 结算方式
     */
    private String settleMode;

    /**
     * 营业周期
     */
    private String dayCut;

    /**
     * 是否允许商户自主变更结算账户
     */
    private String accountChangeFlag;

    /**
     * 结算附言
     */
    private String postscript;

    /**
     * 费率列表
     */
    private List<RateInfoDto> rateInfo;

    // 辅助证明材料
    /**
     * 银行客户经理工号
     */
    private String bankServerId;

    /**
     * 银行编号
     */
    private String bankCode;

    // 身份信息
    /**
     * 主体类型
     */
    private String merchType;

    // 营业证明信息
    /**
     * 执照类型
     */
    private String licenseType;

    /**
     * 注册号/统一社会信用代码
     */
    private String licenseNo;

    /**
     * 登记证书编号
     */
    private String certNumber;

    /**
     * 商户法定名称
     */
    private String licenseName;

    /**
     * 经营范围
     */
    private String businessScope;

    /**
     * 注册地址
     */
    private String licenseAddress;

    /**
     * 有效期限开始日期
     */
    private String periodBegin;

    /**
     * 有效期限结束日期
     */
    private String periodEnd;

    // 经营者/法人信息
    /**
     * 证件类型
     */
    private String idDocType;

    /**
     * 经营者/法人姓名
     */
    @Decrypt
    private String idCardName;

    /**
     * 经营者/法人英文名称
     */
    @Decrypt
    private String idCardEnglishName;

    /**
     * 经营者/法人证件号码
     */
    @Decrypt
    private String idCardNo;

    /**
     * 法人姓名
     */
    @Decrypt
    private String legalPersonName;

    /**
     * 经营者/法人手机号码
     */
    @Decrypt
    private String legalPersonPhone;

    /**
     * 证件有效期开始时间
     */
    private String cardPeriodBegin;

    /**
     * 证件有效期结束时间
     */
    private String cardPeriodEnd;
}
