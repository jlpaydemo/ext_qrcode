package com.jlpay.ext.qrcode.trans.request;

import com.alibaba.fastjson.annotation.JSONField;

public class GetOpenIdRequest extends TransBaseRequest {

    private String service = "getopenid";
    @JSONField(name = "pay_type")
    private String payType;
    @JSONField(name = "auth_code")
    private String authCode;
    @JSONField(name = "sub_appid")
    private String subAppid;
    @JSONField(name = "channel_agent")
    private String channelAgent;
    @JSONField(name = "app_up_identifier")
    private String appUpIdentifier;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public String getSubAppid() {
        return subAppid;
    }

    public void setSubAppid(String subAppid) {
        this.subAppid = subAppid;
    }

    public String getChannelAgent() {
        return channelAgent;
    }

    public void setChannelAgent(String channelAgent) {
        this.channelAgent = channelAgent;
    }

    public String getAppUpIdentifier() {
        return appUpIdentifier;
    }

    public void setAppUpIdentifier(String appUpIdentifier) {
        this.appUpIdentifier = appUpIdentifier;
    }

}
