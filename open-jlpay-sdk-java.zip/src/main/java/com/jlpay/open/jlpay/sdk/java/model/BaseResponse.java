package com.jlpay.open.jlpay.sdk.java.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * @author zhaomeixia
 * @since 3.4.0
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BaseResponse {

    @JsonProperty("ret_code")
    private String retCode;

    @JsonProperty("ret_msg")
    private String retMsg;
}
