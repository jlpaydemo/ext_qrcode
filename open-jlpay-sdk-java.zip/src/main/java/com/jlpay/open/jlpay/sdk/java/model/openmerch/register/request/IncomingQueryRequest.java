package com.jlpay.open.jlpay.sdk.java.model.openmerch.register.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.OrgBaseReq;
import lombok.*;

/**
 * @author liuaobo
 * createTime 2024/3/19
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class IncomingQueryRequest extends OrgBaseReq {

    /**
     * 申请单号
     */
    private String applyId;

    @Override
    public String path() {
        return "/open/merch/access/incoming/query";
    }
}
