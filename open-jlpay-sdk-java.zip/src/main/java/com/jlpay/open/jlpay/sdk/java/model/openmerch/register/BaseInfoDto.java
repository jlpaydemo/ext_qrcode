package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Encrypt;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.BooleanEnum;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.ProductType;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.SignMode;
import lombok.*;

/**
 * 基础信息
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class BaseInfoDto {

    /**
     * 业务申请单号
     */
    private String applyId;

    /**
     * 产品类型
     */
    private ProductType productType;

    /**
     * 签约模式
     */
    private SignMode signMode;

    /**
     * 签约附件
     */
    private String agreementPic;

    /**
     * 直属服务商
     */
    private String agentId;

    /**
     * 是否生成码付终端号
     */
    private BooleanEnum qrcodeTermAuto;

    /**
     * 联系人信息
     */
    @Encrypt
    private ContactInfoDto contactInfo;
}
