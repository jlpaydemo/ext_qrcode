package com.jlpay.open.jlpay.sdk.java.model.openmerch.change.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.BaseResponse;
import lombok.*;

/**
 * 商户信息修改响应
 *
 * @author liuaobo
 * @since 2024/3/27
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MerchInfoChangeResponse extends BaseResponse {

    /**
     * 商户号
     */
    private String merchNo;

    /**
     * 业务申请编号
     */
    private String applyId;

}
