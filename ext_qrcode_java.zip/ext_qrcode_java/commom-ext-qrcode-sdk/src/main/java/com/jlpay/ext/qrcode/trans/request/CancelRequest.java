package com.jlpay.ext.qrcode.trans.request;

import com.alibaba.fastjson.annotation.JSONField;

public class CancelRequest extends TransBaseRequest {

    private String service = "cancel";
    @JSONField(name = "pay_type")
    private String payType;
    @JSONField(name = "out_trade_no")
    private String outTradeNo;
    @JSONField(name = "ori_out_trade_no")
    private String oriOutTradeNo;
    @JSONField(name = "total_fee")
    private String totalFee;
    @JSONField(name = "mch_create_ip")
    private String mchCreateIp;

    @JSONField(name = "longitude")
    private String longitude;
    @JSONField(name = "latitude")
    private String latitude;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getOriOutTradeNo() {
        return oriOutTradeNo;
    }

    public void setOriOutTradeNo(String oriOutTradeNo) {
        this.oriOutTradeNo = oriOutTradeNo;
    }

    public String getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(String totalFee) {
        this.totalFee = totalFee;
    }

    public String getMchCreateIp() {
        return mchCreateIp;
    }

    public void setMchCreateIp(String mchCreateIp) {
        this.mchCreateIp = mchCreateIp;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

}
