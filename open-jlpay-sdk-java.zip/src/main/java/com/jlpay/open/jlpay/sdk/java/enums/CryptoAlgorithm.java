package com.jlpay.open.jlpay.sdk.java.enums;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum CryptoAlgorithm {
    /**
     * SM2WithSM4
     */
    SM2_WITH_SM4("SM2WithSM4");

    @JsonValue
    private final String code;
}