package com.jlpay.open.jlpay.sdk.java.model.notify;


/***
 * 回调请求参数
 * @author xuexiaoya
 * @date 2024/3/14
 **/
public class NotifyParam {

    private static final String SEPARATOR = "\n";

    private final String body;
    private final String nonce;

    private final String timestamp;

    private final String alg;

    private final String sign;


    private final String method;

    private final String uri;


    private NotifyParam(final NotifyParamBuilder<?, ?> builder) {
        this.body = builder.body;
        this.nonce = builder.nonce;
        this.timestamp = builder.timestamp;
        this.alg = builder.alg;
        this.sign = builder.sign;
        this.method = builder.method;
        this.uri = builder.uri;
    }


    public String buildSignContent() {
        return method + SEPARATOR + uri + SEPARATOR + timestamp + SEPARATOR + nonce + SEPARATOR + body + SEPARATOR;
    }

    public static NotifyParamBuilder<?, ?> builder() {
        return new NotifyParamBuilderImpl();
    }

    public String getBody() {
        return body;
    }


    public String getNonce() {
        return nonce;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getAlg() {
        return alg;
    }

    public String getSign() {
        return sign;
    }

    public String getMethod() {
        return method;
    }

    public String getUri() {
        return uri;
    }

    @Override
    public String toString() {
        return "NotifyParam{" +
                "body='" + body + '\'' +
                ", nonce='" + nonce + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", alg='" + alg + '\'' +
                ", sign='" + sign + '\'' +
                ", method='" + method + '\'' +
                ", uri='" + uri + '\'' +
                '}';
    }

    public abstract static class NotifyParamBuilder<C extends NotifyParam, B extends NotifyParam.NotifyParamBuilder<C, B>> {
        private String body;
        private String nonce;

        private String timestamp;

        private String alg;

        private String sign;


        private String method;

        private String uri;

        public B body(final String body) {
            this.body = body;
            return self();
        }


        public B nonce(final String nonce) {
            this.nonce = nonce;
            return self();

        }

        public B timestamp(final String timestamp) {
            this.timestamp = timestamp;
            return self();
        }

        public B alg(final String alg) {
            this.alg = alg;
            return self();
        }

        public B sign(final String sign) {
            this.sign = sign;
            return self();
        }


        public B method(final String method) {
            this.method = method;
            return self();
        }

        public B uri(final String uri) {
            this.uri = uri;
            return self();
        }

        protected abstract B self();

        public abstract C build();


        @Override
        public String toString() {
            return "NotifyParamBuilder{" +
                    "body='" + body +
                    ", nonce='" + nonce +
                    ", timestamp='" + timestamp +
                    ", alg='" + alg +
                    ", sign='" + sign +
                    ", method='" + method +
                    ", uri='" + uri +
                    '}';
        }
    }

    private static final class NotifyParamBuilderImpl extends NotifyParam.NotifyParamBuilder<NotifyParam, NotifyParam.NotifyParamBuilderImpl> {
        private NotifyParamBuilderImpl() {
        }

        @Override
        protected NotifyParam.NotifyParamBuilderImpl self() {
            return this;
        }

        @Override
        public NotifyParam build() {
            return new NotifyParam(this);
        }
    }

}
