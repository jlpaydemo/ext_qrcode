package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.FileType;
import lombok.*;

/**
 * 辅助证明材料
 *
 * @author zhangyinda
 * @since 2024/3/19
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ProofInfoDto {

    /**
     * 附件类型
     */
    private String type;

    /**
     * 文件类型
     */
    private FileType fileType;

    /**
     * 视频地址
     */
    private String mediaPath;
}
