package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Encrypt;
import lombok.*;

/**
 * 合规相关
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class SpecsInfoDto {
    /**
     * 结算类型
     */
    private String settleType;

    /**
     * 结算账户号
     */
    @Encrypt
    private String accountNo;

    /**
     * 结算账户名称
     */
    @Encrypt
    private String accountName;

    /**
     * 开户银行总行代码
     */
    private String bankCode;

    /**
     * 开户行分支行联行号
     */
    private String bankBranchId;

    /**
     * 开户行分支行名称
     */
    private String bankBranchName;

    /**
     * 合规结算账户照片
     */
    private String accountPic;
}
