package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 商户类型
 *
 * @author zhangyinda
 * @since 2024/3/16
 */
@Getter
@RequiredArgsConstructor
public enum MerchType {

    /**
     * 小微商户
     */
    MICRO_MERCHANT("0","SBM"),

    /**
     * 营业执照
     */
    BUSINESS_LICENSE("1","COM");

    @JsonValue
    private final String code;
    private final String value;
}
