package com.jlpay.open.jlpay.sdk.java.model.openmerch.register.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.model.BaseResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 商户进件响应
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class IncomingModifyResponse extends BaseResponse {
    /**
     * 业务申请单号
     */
    private String applyId;
}
