package com.jlpay.open.jlpay.sdk.java.model.openmerch;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 性别
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@RequiredArgsConstructor
public enum Gender {

    /**
     * 男性
     */
    MALE("01"),

    /**
     * 女性
     */
    FEMALE("02");

    @JsonValue
    private final String code;
}
