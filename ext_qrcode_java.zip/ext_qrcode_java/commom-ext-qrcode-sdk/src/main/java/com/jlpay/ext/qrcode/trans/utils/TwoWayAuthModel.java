package com.jlpay.ext.qrcode.trans.utils;

public class TwoWayAuthModel {

    private String serverCertPassword;
    private String clientCertPassword;
    private String serverCertFilePath;
    private String clientCertFilePath;
    private String serverCertType = "jks";
    private String clientCertType = "PKCS12";

    public String getServerCertPassword() {
        return serverCertPassword;
    }

    public void setServerCertPassword(String serverCertPassword) {
        this.serverCertPassword = serverCertPassword;
    }

    public String getClientCertPassword() {
        return clientCertPassword;
    }

    public void setClientCertPassword(String clientCertPassword) {
        this.clientCertPassword = clientCertPassword;
    }

    public String getServerCertFilePath() {
        return serverCertFilePath;
    }

    public void setServerCertFilePath(String serverCertFilePath) {
        this.serverCertFilePath = serverCertFilePath;
    }

    public String getClientCertFilePath() {
        return clientCertFilePath;
    }

    public void setClientCertFilePath(String clientCertFilePath) {
        this.clientCertFilePath = clientCertFilePath;
    }

    public String getServerCertType() {
        return serverCertType;
    }

    public void setServerCertType(String serverCertType) {
        this.serverCertType = serverCertType;
    }

    public String getClientCertType() {
        return clientCertType;
    }

    public void setClientCertType(String clientCertType) {
        this.clientCertType = clientCertType;
    }

}
