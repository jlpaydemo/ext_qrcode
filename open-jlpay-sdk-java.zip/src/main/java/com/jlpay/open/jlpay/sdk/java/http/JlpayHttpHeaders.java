package com.jlpay.open.jlpay.sdk.java.http;

import lombok.experimental.UtilityClass;

/**
 * @author zhangyinda
 * @since 2024/1/25
 */
@UtilityClass
public class JlpayHttpHeaders {

    public static final String ACCEPT = "Accept";
    public static final String CONTENT_TYPE = "Content-Type";

    @UtilityClass
    public static class MediaType {
        public static final String APPLICATION_JSON_UTF8 = "application/json; charset=utf-8";

        public static final String MULTIPART_FORM_DATA_VALUE = "multipart/form-data";
    }

    @UtilityClass
    public static class V5 {

        public static final int NONCE_LENGTH = 32;
        public static final String APP_ID = "x-jlpay-appid";
        public static final String NONCE = "x-jlpay-nonce";
        public static final String TIMESTAMP = "x-jlpay-timestamp";
        public static final String SIGN_ALG = "x-jlpay-sign-alg";
        public static final String SIGN = "x-jlpay-sign";
        public static final String ORG_NO = "x-jlpay-orgno";
        public static final String MERCH_NO = "x-jlpay-merchno";
        public static final String ALG_SM3_WITH_SM2_WITH_DER = "SM3WithSM2WithDer";
    }

    @UtilityClass
    public static class Crypto {
        public static final String CRYPTO_ALG = "x-jlpay-crypto-alg";

        public static final String CRYPTO_KEY = "x-jlpay-key";
    }
}
