package com.jlpay.open.jlpay.sdk.java.http;

/**
 * @author zhaomeixia
 * @since 3.4.0
 */
public interface HttpClient {

    /**
     * 发送请求
     *
     * @param httpRequest   请求参数
     * @param responseClass 返回参数类型
     * @param <T>           返回参数类型
     * @return 返回参数
     */
    <T> T post(HttpRequest httpRequest, Class<T> responseClass);

    HttpResponse post(HttpRequest httpRequest);

    /**
     * 发送表单请求
     * @param httpRequest
     * @param responseClass
     * @return
     * @param <T>
     */
    <T> T postForm(MultipartHttpRequest httpRequest, Class<T> responseClass);
}
