package com.jlpay.open.jlpay.sdk.java.model.upload.request;


import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * 视频上传请求参数
 *
 * @author xuexiaoya
 * @version 2024/03/04
 **/
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
public class VideoUploadReq extends UploadBaseReq {

    @Override
    public String path() {
        return "/base/file/upload/video";
    }

}
