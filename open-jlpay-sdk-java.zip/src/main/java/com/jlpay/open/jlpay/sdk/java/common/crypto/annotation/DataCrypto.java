package com.jlpay.open.jlpay.sdk.java.common.crypto.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 数据加解密
 *
 * @author zhangyinda
 * @since 2024/3/31
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface DataCrypto {
    /**
     * 是否需要加密
     */
    boolean encrypt() default false;

    /**
     * 是否需要解密
     */
    boolean decrypt() default false;
}
