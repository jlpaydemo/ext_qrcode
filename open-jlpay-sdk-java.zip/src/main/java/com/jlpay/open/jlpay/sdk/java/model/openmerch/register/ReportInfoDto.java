package com.jlpay.open.jlpay.sdk.java.model.openmerch.register;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;

/**
 * 报备相关
 *
 * @author zhangyinda
 * @since 2024/3/18
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ReportInfoDto {

    /**
     * 渠道类型
     */
    private String channelType;

    /**
     * 银联服务商号
     */
    private String unionpayPid;

    /**
     * 银联经营名称
     */
    private String unionpayName;

    /**
     * 微信服务商号
     */
    private String wechatPid;

    /**
     * 微信经营名称
     */
    private String wechatName;

    /**
     * 微信支付目录
     */
    private String wechatJsapiPath;

    /**
     * 微信appid
     */
    private String wechatSubAppid;

    /**
     * 支付宝服务商号
     */
    private String alipayPid;

    /**
     * 支付宝经营名称
     */
    private String alipayName;
}
