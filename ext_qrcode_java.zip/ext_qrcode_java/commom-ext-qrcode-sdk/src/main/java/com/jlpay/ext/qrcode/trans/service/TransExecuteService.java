package com.jlpay.ext.qrcode.trans.service;

import com.alibaba.fastjson.JSON;
import com.jlpay.ext.qrcode.common.service.CommonService;
import com.jlpay.ext.qrcode.trans.constants.ExtConstants;
import com.jlpay.ext.qrcode.trans.request.TransBaseRequest;
import com.jlpay.ext.qrcode.trans.response.TransBaseResponse;
import com.jlpay.ext.qrcode.trans.utils.ErrorConstants;
import com.jlpay.ext.qrcode.trans.utils.JlpayException;

/**
 * @author zhaoyang2
 * 交易执行类
 */
public class TransExecuteService {

    @SuppressWarnings("unchecked")
    public static <T extends TransBaseResponse> T executor(String service, TransBaseRequest request, Class<? extends TransBaseResponse> clazz) {

        String sysPriKey = System.getProperty(ExtConstants.orgPrivateKey);
        String jlPubKey = System.getProperty(ExtConstants.jlpayPublicKey);
        String tradeUrl = System.getProperty(ExtConstants.tradeUrl);
        if (null == sysPriKey || null == jlPubKey || null == tradeUrl) {
            throw new JlpayException(ErrorConstants.VALIDATE_ERROR_1, "请设置系统参数");
        }

        //签名
        String requestStr = CommonService.sign(request, sysPriKey);

        //http请求
        String responseStr = CommonService.httpToInvoke(requestStr, tradeUrl + service);

        //验签
        CommonService.checkSign(responseStr, jlPubKey);

        return (T) JSON.parseObject(responseStr, clazz);

    }
}
