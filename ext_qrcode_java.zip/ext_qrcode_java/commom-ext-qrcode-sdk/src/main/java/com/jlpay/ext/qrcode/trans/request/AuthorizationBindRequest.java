package com.jlpay.ext.qrcode.trans.request;

import com.alibaba.fastjson.annotation.JSONField;

public class AuthorizationBindRequest extends TransBaseRequest {

    private String service = "authbind";
    @JSONField(name = "pay_type")
    private String payType;
    @JSONField(name = "jsapi_path")
    private String jsapiPath;
    @JSONField(name = "sub_appid")
    private String subAppid;
    @JSONField(name = "mch_create_ip")
    private String mchCreateIp;
    @JSONField(name = "subscribe_appid")
    private String subscribeAppid;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getJsapiPath() {
        return jsapiPath;
    }

    public void setJsapiPath(String jsapiPath) {
        this.jsapiPath = jsapiPath;
    }

    public String getSubAppid() {
        return subAppid;
    }

    public void setSubAppid(String subAppid) {
        this.subAppid = subAppid;
    }

    public String getMchCreateIp() {
        return mchCreateIp;
    }

    public void setMchCreateIp(String mchCreateIp) {
        this.mchCreateIp = mchCreateIp;
    }

    public String getSubscribeAppid() {
        return subscribeAppid;
    }

    public void setSubscribeAppid(String subscribeAppid) {
        this.subscribeAppid = subscribeAppid;
    }

}
