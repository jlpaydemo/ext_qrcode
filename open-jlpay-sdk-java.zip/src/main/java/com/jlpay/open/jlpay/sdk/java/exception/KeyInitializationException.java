package com.jlpay.open.jlpay.sdk.java.exception;

/**
 * 密钥初始化异常
 *
 * @author zhaomeixia
 * @since 2024/2/20
 */
public class KeyInitializationException extends JlpayException {

    public KeyInitializationException(String message) {
        super(message);
    }

    public KeyInitializationException(String message, Throwable cause) {
        super(message, cause);
    }
}
