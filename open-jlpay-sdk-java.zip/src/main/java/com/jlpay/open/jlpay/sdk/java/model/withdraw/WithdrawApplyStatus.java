package com.jlpay.open.jlpay.sdk.java.model.withdraw;

/**
 * 提现申请状态
 *
 * @author zhaomeixia
 * @since 2024/1/24
 */
public enum WithdrawApplyStatus {

    /**
     * 处理中
     */
    PROCESSING,

    /**
     * 成功
     */
    SUCCESS,

    /**
     * 失败
     */
    FAIL
    ;
}
