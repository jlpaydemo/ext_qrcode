package com.jlpay.ext.qrcode.trans.utils;

import java.text.MessageFormat;

/**
 * 嘉联支付断言类
 *
 * @author lujianyuan
 */
public abstract class JlpayAssert {

    /**
     * 断言对象为空，如果对象不为空时，抛出E0异常
     *
     * @param obj
     * @param pattern
     * @param arguments
     */
    public static void isNull(Object obj, String pattern, Object... arguments) {
        if (obj != null) {
            throwsException(ErrorConstants.EMPTY, pattern, arguments);
        }
    }

    /**
     * 断言对象不为空，如果对象为空抛出E1异常
     *
     * @param obj
     * @param pattern
     * @param arguments
     */
    public static void notNull(Object obj, String pattern, Object... arguments) {
        if (obj == null) {
            throwsException(ErrorConstants.NOT_EMPTY, pattern, arguments);
        }
    }

    /**
     * 爆出异常
     *
     * @param code      异常代码
     * @param pattern   异常描述
     * @param arguments 匹配值
     */
    private static void throwsException(String code, String pattern, Object... arguments) {
        String msg = arguments != null ? MessageFormat.format(pattern, arguments) : pattern;
        throw new JlpayException(code, msg);
    }

    /**
     * 断言字符串不为空，如果对象为空抛出E1异常。
     * 例如：                                                  							<br/>
     * <code>
     * String str=null;
     * String str="";
     * String str="  "
     * </code>
     * 以上代码均会抛出E1异常
     *
     * @param str
     * @param pattern
     * @param arguments
     */
    public static void notEmpty(String str, String pattern, Object... arguments) {
        notNull(str, pattern, arguments);
        if (str.trim().equals("")) {
            throwsException(ErrorConstants.NOT_EMPTY, pattern, arguments);
        }
    }

    /**
     * 断言表达式为真，如果表达式为false时，抛出异常
     *
     * @param expression 表达式
     * @param pattern    异常信息
     * @param arguments
     */
    public static void isTrue(boolean expression, String pattern, Object... arguments) {
        if (!expression) {
            throwsException(ErrorConstants.VALIDATE_ERROR_1, pattern, arguments);
        }
    }

    public static void isTrue(boolean expression, String code, String pattern, Object... arguments) {
        if (!expression) {
            throwsException(code, pattern, arguments);
        }
    }

    /**
     * 断言表达式为false 如果表达式为真是抛出异常
     *
     * @param expression
     * @param pattern
     * @param arguments
     */
    public static void isFalse(boolean expression, String pattern, Object... arguments) {
        if (expression) {
            throwsException(ErrorConstants.VALIDATE_ERROR_2, pattern, arguments);
        }
    }

    /**
     * 断言表达式为false 如果表达式为真是抛出异常
     *
     * @param expression
     * @param code
     * @param pattern
     * @param arguments
     */
    public static void isFalse(boolean expression, String code, String pattern, Object... arguments) {
        if (expression) {
            throwsException(code, pattern, arguments);
        }
    }
}
