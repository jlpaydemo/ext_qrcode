package com.jlpay.open.jlpay.sdk.java.http;

/**
 * @author zhaomeixia
 * @since 2024/2/20
 */
public enum HttpMethod {
    GET,
    POST,
    PUT,
    DELETE,
    PATCH,
    HEAD,
    OPTIONS,
    TRACE
}
