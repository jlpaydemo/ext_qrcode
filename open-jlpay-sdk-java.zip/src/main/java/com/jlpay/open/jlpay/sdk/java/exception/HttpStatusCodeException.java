package com.jlpay.open.jlpay.sdk.java.exception;

/**
 * HTTP 状态码异常
 *
 * @author zhaomeixia
 * @since 2024/2/20
 */
public class HttpStatusCodeException extends JlpayException {

    private final int httpStatusCode;

    private final String responseBody;

    public HttpStatusCodeException(int httpStatusCode, String responseBody) {
        super(String.format("Unexpected http status code %d, response: %s", httpStatusCode, responseBody));
        this.httpStatusCode = httpStatusCode;
        this.responseBody = responseBody;
    }
}
