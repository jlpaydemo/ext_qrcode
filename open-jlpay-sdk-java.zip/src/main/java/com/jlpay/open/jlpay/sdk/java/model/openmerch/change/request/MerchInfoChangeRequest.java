package com.jlpay.open.jlpay.sdk.java.model.openmerch.change.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.DataCrypto;
import com.jlpay.open.jlpay.sdk.java.common.crypto.annotation.Encrypt;
import com.jlpay.open.jlpay.sdk.java.model.OrgBaseReq;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.change.MerchBaseInfoDto;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.change.MerchBusinessInfoDto;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.change.MerchIdentificationInfoDto;
import com.jlpay.open.jlpay.sdk.java.model.openmerch.change.MerchSettleInfoDto;
import lombok.*;

/**
 * 商户信息修改请求
 *
 * @author zhangyinda
 * @since 2024/4/8
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@DataCrypto(encrypt = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MerchInfoChangeRequest extends OrgBaseReq {
    /**
     * 商户基础信息
     */
    private MerchBaseInfoDto baseInfo;

    /**
     * 商户业务信息
     */
    private MerchBusinessInfoDto businessInfo;

    /**
     * 结算信息
     */
    private MerchSettleInfoDto settleInfo;

    /**
     * 商户身份信息
     */
    @Encrypt
    private MerchIdentificationInfoDto identificationInfo;

    @Override
    public String path() {
        return "/open/merch/access/merch-info/modify";
    }
}
